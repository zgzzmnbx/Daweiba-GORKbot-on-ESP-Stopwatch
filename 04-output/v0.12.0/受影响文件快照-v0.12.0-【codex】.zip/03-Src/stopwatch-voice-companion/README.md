# Gork 机器人控制台后端与网页 v0.12.0-dev

## v0.11.0 项目内语音运行时

默认托管 `../voice-service/tools/serve_managed.py`，使用项目根目录 `Codex-Temp/voice-runtime/.venv/` 与其中 models/，不再依赖旧语音项目。省略 voice_service_command/cwd 使用默认值；显式空数组可禁用托管，仅复用。Windows 专用 Key 环境变量机制不变，凭据不写入配置。以下 v0.8.8 的外部项目路径说明是历史记录。

## v0.10.0 自适应界面

- 左侧机器人与状态开关常驻，右侧四标签内部滚动，底部输入区随窗口适配。
- 默认云端朗读、本地识别；恢复已有路由与撤销许可。不会因默认值自动发请求。
- AI 回答保留在消息区，不覆盖草稿；可单独朗读/复制。自动朗读和页面表情联动可关闭，桌面窗口开关仅 Electron 可用。
- 录音使用点击开始/结束；切换模块或窗口失焦停止收音。设备控制权可独立于语音申请。
- 设置普通草稿不会打断当前会话；许可撤销立即取消相关路径。保存成功后才更新持久化偏好。

## v0.9.0 四页控制台

- 入口分为对话、角色、StopWatch、设置；hash 深链接在刷新、前进和后退后保留。
- 工作台控制权与语音会话分别管理。角色/设备写入要求工作台 owner；ASR/TTS 另要求已连接语音会话。工作台租期为 30 秒，由前台心跳续期。
- `static/audio-client.js` 的 Recorder/WavPlayer 可独立使用；`tools/examples/voice_service_http_example.py` 是不依赖 Gork/Watch 的 HTTP 调用入口。
- 手动角色/气泡 API 复用同一 BLE 客户端。桌面气泡显示 8 秒；Watch 使用现有协议限制。`happy-work` 只能发往 Watch。

## v0.8.8 音色与托管

- 声音与隐私选择本地/云端 TTS，下方“音色与试听”选择声音，点击“应用并保存”后试听；本地支持三档语速，云端当前仅 1.0×。音色、语速、路由保存在当前浏览器/Electron 配置中，不保存试听音频。云端试听也需文字上传许可，可能计费。
- 能力目录来自独立语音服务；v0.3.2 提供 Cherry、Serena、Ethan、Chelsie、Momo、Moon。旧 v0.3.1 仅显示其默认音色，不发送不支持的新字段；更新后需重启旧语音服务一次。
- 本机 `config.local.toml` 已配置独立服务 `tools/serve_managed.py`，随后启动控制台即可后台启动语音服务；页面可查看自有/外部/离线和启动重试。只关闭自有实例，外部服务不会被接管或强制重启。
- 新电脑需要自行配置独立语音仓库的 Python、托管入口和工作目录；这些本机路径不入 Git。模型、venv、Key 仍在语音项目；本次未更新旧发行包。

统一管理电脑麦克风/朗读、可选文字回答、桌面角色、StopWatch 表情/气泡、内置声音和延迟 BLE 音频。未配置回答服务时明确保持跟读/朗读，不伪造 AI 回复；设备离线不阻断电脑功能。

## 启动

1. 推荐在项目根目录双击 `start-gork-console.cmd`；网页回退入口仍为 `start-voice-companion.cmd`，默认 `http://127.0.0.1:8766`。
2. 默认复用 `http://127.0.0.1:8765` 的独立语音服务。也可在 `config.local.toml` 明确配置 `voice_service_command` 和 `voice_service_cwd`；程序验证协议后后台启动，并只停止自己启动的实例。不搜索模型、venv 或 Key。
3. 点击“连接会话”。已有会话不会被自动抢占。按用户2026-09-23要求，三项上传许可默认勾选并在连接时应用；保留当前界面选择的路由，不自动切云端或录音。取消勾选会即时撤销并在当前浏览器/桌面配置中保存，重连/刷新不重新开启。
4. 点击“开始录音”，由你确认浏览器的麦克风权限；说话后点“结束并转写”，最长 30 秒自动结束。浏览器实际采集数据会转换成 PCM16、单声道、16 kHz WAV，不是重命名 WebM。
5. 检查/编辑文字后选择“跟读/朗读”；如已配置回答适配器且单独允许发送文字，可选择“AI 对话”。回答超过 300 字时完整显示但不自动朗读，提示用户编辑，不默默截断。
6. 点击“停止”立即停止本地麦克风/播放器，再异步取消服务请求；停止或失败不代表云端不计费。

### 蓝牙联动

- StopWatch 正常运行 v0.5.0；在本地 Bluetooth 设置中打开 BLE，首次连接打开 Pair 窗口，随后退出设置页。
- 关闭旧蓝牙控制台，避免多个程序争抢连接。工作台先“扫描设备”，选择当次发现的 `GorkBot-SW`，再“连接”；不硬编码历史 MAC。
- 录音：`loop listening`；处理：`loop thinking`；电脑实际开始播放：`loop happy`；播放结束/停止：`idle` + 清气泡；错误：`confused`。
- 短气泡显示转写或回读文本预览，最多约 10 秒（设备现有固件行为）。不做逐音素嘴型。
- 后端一个串行 BLE 写入者，文字事务不可插入其他包；每包只认匹配回执，不再读取旧状态当成功。未知写入/回执超时断开连接以隔离迟到回执。
- 每次手动连接后自动重连最多 2 次；只恢复最新状态，不重放旧气泡或语音。失败后按页面提示重新扫描/连接。菜单打开会拒绝控制并提示 `ERR:BUSY`。
- 现有表情和清屏协议没有请求编号，同一连接内的重复同名迟到通知不能做到严格逐请求证明；本版通过串行、清空已排队通知、超时断开和连接代号隔离降低风险，没有冒充协议升级。

### v0.8.0 设备声音与延迟音频

- 声音库提供 6 个原创短音效的电脑试听；设备播放、0–100 音量和停止需要设备已烧录 v0.8.0。声音协议含 request_id，终态缓存 8 条，重复请求不重复出声。
- 延迟模式支持“电脑文字→设备”“设备录音→电脑”“设备录音→处理→设备”。同一 BleakClient 承载表情、声音和音频服务，不启动第二个控制器。
- 页面显示真实阶段、累计字节、总字节、百分比和速率。设备录音仍必须进入 Audio test 页并按 A；最长 10 秒，非实时，可能等待数十秒。
- 取消会停止本地播放器、作废 HTTP generation，并向设备音频会话发送 CANCEL；断线后不续传、不补播。私人 WAV 只在内存中持有，录音结果读取一次后释放。

### 回答适配器

`answer_base_url` 与 `answer_model` 同时配置后才开放 AI 对话；远端服务还必须存在 `answer_api_key_env` 指定的环境变量。请求只发送有限轮文字消息，不发送文件/屏幕，不声明工具，不执行模型输出。回答文本许可与 ASR 录音、TTS 文字许可互不替代，重新连接后归零。

### 选路和上传许可

建议体验路径是本地 ASR + 云端 TTS，但需要你勾选“允许上传回读文字”并应用。允许文字不等于允许录音上传，也不等于允许向回答服务发送文字。三项许可在当前会话内生效，重新连接后归零；配置有 Key 不会自动开启上传。

切换选项会立即停止当前操作；新路径必须点“应用设置”。取消任一上传勾选会立即停止并向服务撤销该项许可，对应路径退回本地。已有云请求可能只作废结果，不能承诺撤销账单。云端账号/Key 只在独立语音服务配置，不放在本仓库。

## 配置与依赖

将 `config.example.toml` 复制为被 Git 忽略的 `config.local.toml` 后修改：工作台端口、独立语音服务地址/可选启动命令、设备预选地址、请求超时、可选回答服务。语音服务地址只允许本机 HTTP；设备地址仅用于本次扫描列表预选，不自动连接。不要把凭据写入配置。

`requirements.txt` 锁定直接依赖；`requirements-lock.txt` 记录本机 Windows/Python 3.14 的完整安装集合。启动器使用独立的 `Codex-Temp/.venv-companion`，不复用 PlatformIO 或语音引擎环境。工作台只监听 127.0.0.1，验证 Host/Origin，不放开跨源权限。多个浏览器标签使用独立内存控制标识；语音服务 session_id 不发给网页，不写 URL 或日志。

启动器先独占绑定端口；若已有同一项目工作台，核对接口应用标识、项目实例和 PID 后打开既有页面；若端口被其他程序占用则报错退出，不按端口杀进程。无自动退出其他 Python 服务的代码。

## 生命周期

同一轮 ASR 与编辑后的 TTS 使用相同服务 turn，不同 request_id；每次操作另有递增 generation。新录音或换路创建新 turn。旧 generation 的 HTTP 完成、播放器回调和未发 BLE 状态都被丢弃；已经写进设备的包无法撤回，随后最新 idle/清屏会覆盖。

前台每秒检查会话，服务检查超时 3 秒、浏览器检查上限 4 秒。会话被接管或断开后停止本地播放，不自动抢回。关闭页面尽力释放会话；如果浏览器崩溃未能释放，下次由用户明确接管。

## 验证

在项目根目录运行：

```powershell
$env:PYTHONPATH='03-Src/stopwatch-voice-companion'
& 'Codex-Temp/.venv-companion/Scripts/python.exe' -m pytest '03-Src/stopwatch-voice-companion/tests' tools/test_ble_expression_console.py tools/test_grok_bot_catalog.py tools/test_grok_geometry.py tools/test_stopwatch_audio.py tools/test_stopwatch_sound.py -q
node --test '03-Src/stopwatch-voice-companion/tests/test_browser.mjs'
npm test --prefix '03-Src/gork-desktop'
```

可选本地服务联测（先退出工作台会话，不会抢占）：

```powershell
& 'Codex-Temp/.venv-companion/Scripts/python.exe' -X utf8 '03-Src/stopwatch-voice-companion/tests/live_smoke.py'
```

该脚本用本地 TTS 生成测试 WAV 后送入本地 ASR，不开启麦克风、不上传云端、不存原始音频，不能代替真人录音与听感验收。v0.8.0 完整结果与未测项见项目 `04-output/v0.8.0/实施与验收记录-【codex】.md`。
