const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('gorkDesktop', Object.freeze({
  openConsole: () => ipcRenderer.invoke('gork:open-console'),
  hideAvatar: () => ipcRenderer.invoke('gork:hide-avatar'),
  stopAll: () => ipcRenderer.invoke('gork:stop-all'),
  getAvatarScale: () => ipcRenderer.invoke('gork:avatar-scale'),
  setAvatarScale: (percent) => ipcRenderer.invoke('gork:set-avatar-scale', percent),
  getAvatarVisible: () => ipcRenderer.invoke('gork:avatar-visible'),
  setAvatarVisible: (visible) => ipcRenderer.invoke('gork:set-avatar-visible', visible),
  getState: () => ipcRenderer.invoke('gork:get-state'),
  onState: (callback) => {
    const listener = (_event, state) => callback(state);
    ipcRenderer.on('gork:state', listener);
    return () => ipcRenderer.removeListener('gork:state', listener);
  },
  onStopAll: (callback) => {
    const listener = () => callback();
    ipcRenderer.on('gork:stop-local', listener);
    return () => ipcRenderer.removeListener('gork:stop-local', listener);
  },
}));
