import {Epoch} from './pcm.js';
import {Recorder, WavPlayer} from './audio-client.js';
import {createDebugConsole} from './debug-console.js';
import {createExpressionMenu} from './expression-menu.js';
import {createAppearancePicker} from './appearance-picker.js';
import {createExternalUI} from './external-ui.js';
import {createWatchChat} from './watch-chat.js';

const $ = id => document.getElementById(id);
let debugStorage;
try { debugStorage = window.localStorage; } catch {}
const debugConsole = createDebugConsole(document, debugStorage, text => navigator.clipboard.writeText(text));
const face = (window.GorkDesktopSceneAdapter || window.GorkAvatar)?.mount($('gork-face'));
const characterFace = face;
let manualPreview = false, manualPreviewUntil = 0, lastFaceState = '', renderedPage = '';
let sentinelFace = 'idle',answerMotion = null, externalPresentation = null, lastExternalRevision = null;
let sentinelEnabled = false, externalProtocol = false;
let expressionMenu = null, expressionPending = false, customExpressions = [];
function shareAvatarScene(expression, mode = 'loop', startedAt = Date.now()) {
  if (customExpressions.some(entry=>entry.id===expression)) { window.gorkDesktop?.playCustomExpression?.(expression,mode)?.catch(error=>message(error.message,true));return; }
  window.gorkDesktop?.setAvatarScene?.({expression, mode, startedAt})?.catch(() => {});
}
let appliedTts = '';
let recordingPending = false, connectionPending = false, previewSerial = 0;
for (const id of ['auto-read', 'expression-follow']) {
  try { $(id).checked = window.localStorage?.getItem('gork.' + id) !== 'false'; } catch { $(id).checked = true; }
}
// One-time migration to the requested cloud defaults. Later manual selections
// and independent upload revocations continue to survive reloads.
$('asr').value = $('tts').value = 'cloud';
let migrateCloudDefaults = true;
try {
  migrateCloudDefaults = window.localStorage?.getItem('gork.cloud-defaults-v1') !== 'true';
  if (migrateCloudDefaults) {
    for (const id of ['asr', 'tts']) window.localStorage?.setItem('gork.' + id, 'cloud');
    window.localStorage?.setItem('gork.cloud-defaults-v1', 'true');
  }
} catch {}
const consentIds = ['audio-consent','text-consent','answer-consent'];
for (const id of consentIds) {
  let saved = null;
  try { saved = window.localStorage?.getItem('gork.' + id); } catch {}
  $(id).checked = saved !== 'false';
}
const epoch = new Epoch();
let client = crypto.randomUUID(), connected = false, workspace = false, dirty = false, phase = 'idle';
let turnReady = false;
let context, playback, deadline;
let previewContext, previewPlayback, robotConnected = false, robotRoute = '';
let watchSpeechSync = false;
let answerSpeechContinuity=false;
const previewPlayer = new WavPlayer();
const recorder = new Recorder();
let delayBusy = false, outputPending = false, composerWatchAudio = false, composerWatchProgress = '';
let tick = false, polling = false, suggestedAddress = '';
let healthPolling = false, watchDelegated = false, healthIdleTicks = 0;
let capabilities = null, serviceStarting = false, startupVoiceTimer = null;
let voiceHealthFailures = 0, voiceHealthState = '';
const startupVoice = {enabled: true, done: false, active: false, attempts: 0, maxAttempts: 60};
let savedSpeech = {speaker_id:3, cloud_voice:'Cherry', speed:1.0};
try {
  const saved = JSON.parse(window.localStorage?.getItem('gork.speech') || 'null');
  if (saved && typeof saved === 'object') savedSpeech = {...savedSpeech,...saved};
  for (const id of ['asr','tts']) {
    const value = window.localStorage?.getItem('gork.' + id);
    if (!migrateCloudDefaults && ['local','cloud'].includes(value)) $(id).value = value;
  }
} catch {}
if (!$('text-consent').checked) $('tts').value = 'local';
if (!$('audio-consent').checked) $('asr').value = 'local';
$('voice-speed').value = String(savedSpeech.speed);
const labels = {idle: '待机', listening: '正在聆听', processing: '处理中', speaking: '正在回读', ready: '文字已就绪', error: '请检查连接'};
$('output-mode').value = 'pc';
$('bubble-target').value = 'both';

function message(text, error = false) {
  $('message').textContent = text; $('message').className = 'message' + (error ? ' error' : '');
  // Raw failures may contain provider payloads. Keep them out of telemetry history.
  debugConsole.push('UI', error ? '操作失败；请查看工作区提示（原始错误不写入日志）' : text, error);
}
const watchRows = new Map();
const watchChat = createWatchChat(addMessage);
function addMessage(role, text, metadata = {}) {
  if (!document.createElement) return;
  const previous = metadata.id && watchRows.get(metadata.id);
  if (previous) {
    previous.content.textContent = text;
    previous.label.textContent = `${role === 'user' ? '你' : 'Gork'} · ${metadata.source}${metadata.timing ? ' · '+metadata.timing : ''}`;
    return;
  }
  $('empty-chat')?.remove();
  const row = document.createElement('article'); row.className = 'chat-message ' + role;
  const label = document.createElement('small'); label.textContent = (role === 'user' ? '你' : 'Gork') +
    (metadata.source ? ` · ${metadata.source}${metadata.timing ? ' · '+metadata.timing : ''}` : '');
  const content = document.createElement('div'); content.textContent = text;
  row.append(label, content);
  if (role === 'assistant') {
    const actions = document.createElement('div'); actions.className = 'actions compact';
    const read = document.createElement('button'); read.textContent = '朗读';
    read.onclick = () => speak(false, content.textContent);
    const copy = document.createElement('button'); copy.textContent = '复制';
    copy.onclick = async () => { try { await navigator.clipboard.writeText(content.textContent); message('已复制。'); } catch { message('无法访问剪贴板，请选择文字复制。', true); } };
    actions.append(read, copy); row.append(actions);
  }
  $('chat-log').append(row); $('chat-log').scrollTop = $('chat-log').scrollHeight;
  if (metadata.id) watchRows.set(metadata.id,{content,label,row});
}
function navigate() {
  if (!globalThis.location) return;
  const page = ['dialogue', 'cost', 'external', 'codex', 'motion', 'character', 'watch', 'settings', 'logs'].includes(location.hash.slice(1)) ? location.hash.slice(1) : 'dialogue';
  const motionFrame = $('motion-editor-frame');
  if (motionFrame) { if (page === 'motion' && !motionFrame.getAttribute('src')) motionFrame.src = '/static/motion/index.html'; else if (page !== 'motion' && motionFrame.getAttribute('src')) motionFrame.removeAttribute('src'); }
  if (location.hash !== `#${page}`) history.replaceState(null, '', `#${page}`);
  document.querySelectorAll?.('[data-page]').forEach(item => { item.hidden = item.dataset.page !== page; });
  document.querySelectorAll?.('[data-page-link]').forEach(item => {
    const active = item.dataset.pageLink === page;
    item.classList.toggle('active', active); item.setAttribute('aria-selected', String(active)); item.tabIndex = active ? 0 : -1;
  });
  if (renderedPage && renderedPage !== page && (phase === 'listening' || recordingPending)) stop();
  renderedPage = page;
}
function render(next = phase) {
  phase = next; document.body.dataset.phase = phase;
  if (manualPreview && sentinelEnabled && Date.now() >= manualPreviewUntil) {
    manualPreview = false; lastFaceState = '';
  }
  const automaticExternal = externalPresentation && !['listening','processing','speaking','generating'].includes(next) && !manualPreview && !answerMotion;
  const faceState = automaticExternal ? externalPresentation.expression : $('expression-follow').checked ? (answerMotion?.id || (next === 'idle' ? sentinelFace : next)) : 'idle';
  if ((!manualPreview || answerMotion) && (faceState !== lastFaceState || (automaticExternal && lastExternalRevision !== externalPresentation.revision))) {
    const startedAt = Date.now();
    if(automaticExternal){
      lastExternalRevision=externalPresentation.revision;
      if(externalPresentation.custom_motion)face?.playCustom?.(externalPresentation.custom_motion,{mode:externalPresentation.mode,startedAt});
      else face?.set(faceState,{mode:externalPresentation.mode,startedAt,force:true});
    }
    else if(answerMotion&&faceState===answerMotion.id)face?.playCustom?.(answerMotion,{mode:'loop',startedAt});
    else{face?.set(faceState, {startedAt, force:true}); shareAvatarScene(faceState, 'loop', startedAt);}
    lastFaceState = faceState;
  }
  $('companion-phase').textContent = labels[phase] || '待机';
  $('robot-voice-summary').textContent = connected ? labels[phase] : '未连接';
  $('robot-device-summary').textContent = robotConnected ? '已连接' : '未连接';
  $('robot-route-summary').textContent = (appliedTts || $('tts').value) === 'cloud' ? '云端朗读' : '本地朗读';
  debugConsole.push('VOICE', `${connected ? '会话已连接' : '会话未连接'} · ${labels[phase] || '待机'} · ${$('robot-route-summary').textContent}`);
  $('quick-connect').textContent = connected ? '语音已连接' : '连接语音';
  $('quick-connect').disabled = connected || connectionPending;
  $('phase').textContent = connected ? labels[phase] : '未连接';
  const busy = ['listening', 'processing', 'speaking'].includes(phase);
  $('voice-preview').disabled = !connected || dirty || busy || delayBusy;
  $('voice-stop').disabled = !connected;
  $('voice-start').disabled = serviceStarting;
  $('record').disabled = !connected || !appliedTts || busy || delayBusy; $('record').hidden = phase === 'listening';
  $('finish').hidden = phase !== 'listening'; $('stop').disabled = !connected;
  const output = $('output-mode').value, bubbleTarget = $('bubble-target').value;
  const text = $('transcript').value.trim(), answerMode = $('interaction-mode').value === 'answer';
  const watchTarget = bubbleTarget !== 'desktop';
  const watchBytes = new TextEncoder().encode(text).length;
  const bubbleTooLong = output === 'bubble' && !answerMode && bubbleTarget==='watch' && (Array.from(text).length > 24 || watchBytes > 72);
  $('bubble-target-control').hidden = output !== 'bubble';
  $('speak').disabled = busy || delayBusy || outputPending || !text || bubbleTooLong ||
    (output === 'pc' && (!connected || !appliedTts)) ||
    (output === 'bubble' && (!workspace || (bubbleTarget==='watch' && !robotConnected) || (answerMode && !connected))) ||
    (output === 'watch-audio' && (!workspace || !robotConnected || !connected || !appliedTts || !watchSpeechSync));
  $('speak-label').textContent = output === 'bubble' ? `显示到${bubbleTarget === 'watch' ? ' Watch' : bubbleTarget === 'both' ? '两端' : '桌面'}` :
    output === 'watch-audio' ? 'Watch 朗读' : answerMode && !$('auto-read').checked ? '生成回答' : '电脑朗读';
  $('answer-status').textContent = bubbleTooLong ? `Watch 文字超限：${Array.from(text).length}/24 字、${watchBytes}/72 字节` :
    output === 'bubble' ? (!workspace ? '请先取得工作台控制权；Watch 最多 24 字、72 字节' :
      watchTarget && !robotConnected ? '请先连接 Watch；最多 24 字、72 字节' :
      watchTarget ? 'Watch 最多 24 字、72 字节；桌面最多 300 字' : '桌面小人显示 8 秒；最多 300 字') :
    output === 'watch-audio' ? (!watchSpeechSync ? '请退出并重开 Gork，使文字与 Watch 朗读同步' :
      !workspace || !robotConnected ? '请先取得工作台控制权并连接 Watch；设备朗读仍是延迟实验功能' :
      '音频传完后再显示文字并开始朗读；低电平语音自动增强，最长 10 秒') :
    !connected ? '请先连接语音，再通过电脑扬声器朗读' :
    answerMode ? '先取得 AI 回答，再按自动朗读设置决定是否播放' : '使用电脑扬声器朗读输入文字';
  $('answer-status').hidden = !bubbleTooLong && !((output==='watch-audio'||(output==='bubble'&&bubbleTarget==='watch'))&&!robotConnected);
  $('transcript').readOnly = busy;
  $('connect').hidden = connected; $('release').hidden = !connected;
  $('scan').disabled = !workspace; $('apply').disabled = !connected;
  $('clear-answer').disabled = busy || delayBusy;
  $('sound-preview').disabled = busy;
  $('sound-play').disabled = busy || !workspace || !robotConnected;
  $('sound-stop').disabled = !robotConnected && !previewPlayer.playing;
  $('sound-volume').disabled = busy || !workspace || !robotConnected;
  $('delay-start').disabled = busy || delayBusy || !connected || !robotConnected;
  $('delay-cancel').disabled = !delayBusy;
  $('count').textContent = output === 'bubble' && bubbleTarget==='watch' && !answerMode ?
    `${Array.from($('transcript').value).length}/24字 · ${new TextEncoder().encode($('transcript').value).length}/72B` :
    `${Array.from($('transcript').value).length} / 300`;
  $('global-voice').textContent = `语音：${connected ? labels[phase] : '未连接'}`;
  const watchLink = robotRoute === 'wifi' ? 'Wi-Fi ' : robotRoute === 'ble' ? '蓝牙' : '';
  $('global-watch').textContent = `Watch：${robotConnected ? `${watchLink}已连接` : '未连接'}`;
  $('global-voice').dataset.state = connected ? 'ready' : 'offline';
  $('global-watch').dataset.state = robotConnected ? 'ready' : 'offline';
  $('global-operation').textContent = delayBusy ? '设备音频任务进行中' : labels[phase] || '待机';
  $('workspace-acquire').textContent = workspace ? '已取得控制权' : '取得控制权';
  $('character-play').disabled = !workspace || busy || delayBusy || expressionPending;
  expressionMenu?.update({watchConnected:robotConnected, blocked:busy || delayBusy || outputPending ? '请先结束当前录音、朗读或设备音频任务。' : ''});
  $('bubble-clear').disabled = !workspace || busy || delayBusy;
}
async function api(path, method = 'GET', body, options = {}) {
  const headers = {'X-Companion-Client': client, ...options.headers};
  let payload = body;
  if (body !== undefined && !(body instanceof ArrayBuffer)) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const response = await fetch('/api' + path, {method, headers, body: payload, signal: options.signal, keepalive: options.keepalive});
  if (!response.ok) {
    const detail = await response.json().catch(() => ({}));
    const error = new Error(detail.error?.message || `请求失败（${response.status}）`);
    error.code = detail.error?.code; error.status = response.status; throw error;
  }
  return options.audio ? response.arrayBuffer() : response.json();
}
function localStop() {
  clearTimeout(deadline); clearInterval(tick); tick = false;
  if (playback) { playback.onended = null; try { playback.stop(); } catch {} playback.disconnect(); playback = null; }
  recorder.stop();
  const oldContext = context; context = null;
  if (oldContext && oldContext.state !== 'closed') { oldContext.suspend().catch(() => {}); oldContext.close().catch(() => {}); }
}
function stopPreview() {
  previewSerial++; previewPlayer.stop();
  if (previewPlayback) { previewPlayback.onended = null; try { previewPlayback.stop(); } catch {} previewPlayback.disconnect(); previewPlayback = null; }
  const audio = previewContext; previewContext = null;
  if (audio && audio.state !== 'closed') audio.close().catch(() => {});
  render();
}
function failed(error, gen) {
  if (error.name === 'AbortError' || (gen !== undefined && !epoch.valid(gen))) return;
  recordingPending = false; localStop();
  answerMotion=null;
  if (error.status === 401) { connected = false; epoch.next(); $('takeover').hidden = true; }
  render('error'); message(error.message || '连接中断，请检查服务后重试。', true);
  if (connected && gen !== undefined && epoch.valid(gen)) state('error', gen).catch(() => {});
}
function clearStartupVoiceTimer() {
  if (startupVoiceTimer !== null) clearTimeout(startupVoiceTimer);
  startupVoiceTimer = null;
}
function cancelStartupVoice() {
  clearStartupVoiceTimer(); startupVoice.done = true;
}
function scheduleStartupVoice(delay = 0) {
  if (!startupVoice.enabled || startupVoice.done || startupVoice.active || connected || connectionPending
      || startupVoice.attempts >= startupVoice.maxAttempts || startupVoiceTimer !== null) return;
  startupVoiceTimer = setTimeout(() => { startupVoiceTimer = null; autoConnectVoice(); }, delay);
}
async function autoConnectVoice() {
  if (!startupVoice.enabled || startupVoice.done || startupVoice.active || connected || connectionPending) return;
  startupVoice.active = true; startupVoice.attempts += 1;
  message(startupVoice.attempts === 1 ? '正在自动连接语音…' : '语音服务尚未就绪，正在重试自动连接…');
  let result;
  try { result = await connect(false, {startup:true}); }
  catch (error) { result = {ok:false, error}; }
  finally { startupVoice.active = false; }
  if (result?.ok || connected) { startupVoice.done = true; return; }
  const code = result?.error?.code;
  if (code === 'SESSION_BUSY' || code === 'WORKSPACE_BUSY') {
    startupVoice.done = true;
    message('已有语音会话正在使用，请点击“接管会话”。', true);
    return;
  }
  if (startupVoice.attempts >= startupVoice.maxAttempts) {
    startupVoice.done = true;
    message('开机自动连接语音失败，请点击“连接语音”重试。', true);
    return;
  }
  scheduleStartupVoice(1000);
}
async function stop() {
  turnReady = false;
  recordingPending = false; localStop(); answerMotion=null; const gen = epoch.next(); render('idle'); message('已停止本地录音与播放，正在取消服务请求。');
  const deviceCancel = robotConnected ? api('/device/audio', 'DELETE').catch(() => {}) : Promise.resolve();
  if (connected) {
    try { await api('/stop', 'POST', {generation: gen}); if (epoch.valid(gen)) message('已停止。旧结果不会继续播放；已提交的云端请求可能仍产生费用。'); }
    catch (error) { failed(error, gen); }
  }
  await deviceCancel;
  delayBusy = false; render();
}
async function stopAll() {
  stopPreview();
  await stop();
  try { const result = await api('/desktop/stop', 'POST'); if (Number.isInteger(result.generation)) epoch.value = Math.max(epoch.value, result.generation); message('已停止电脑音频、在途语音与设备操作；设备停止回执以实际返回为准。'); }
  catch (error) { message(error.message, true); }
}
async function state(name, gen) {
  const result=await api('/state', 'POST', {generation: gen, state: name}, {signal: epoch.abort.signal});
  if(epoch.valid(gen)&&'interaction_expression' in result){answerMotion=result.interaction_expression||null;if(answerMotion)manualPreview=false;}
}
async function begin() {
  manualPreview = false; localStop(); answerMotion=null; const gen = epoch.next();
  await api('/begin', 'POST', {generation: gen}, {signal: epoch.abort.signal});
  if (!epoch.valid(gen)) throw new DOMException('旧操作', 'AbortError');
  turnReady = true;
  return gen;
}
async function record() {
  if (!connected || !appliedTts || delayBusy || ['listening','processing','speaking'].includes(phase)) return;
  recordingPending = true; render('processing');
  let gen;
  try {
    gen = await begin(); render('processing');
    const recorderStarted = await recorder.start({maxSeconds: 30});
    if (!recorderStarted || !epoch.valid(gen)) return;
    await state('listening', gen);
    if (!epoch.valid(gen)) return;
    recordingPending = false; render('listening'); message('正在收音。结束后可编辑识别文字，再点击回读。');
    const started = performance.now();
    tick = setInterval(() => { $('record-hint').textContent = `正在录音 ${Math.min(30, (performance.now() - started) / 1000).toFixed(1)} / 30 秒`; }, 100);
    deadline = setTimeout(finish, 30000);
  } catch (error) { failed(error, gen); }
}
async function finish() {
  if (phase !== 'listening') return;
  const gen = epoch.value, wav = recorder.finish();
  localStop(); render('processing'); $('record-hint').textContent = '录音已结束，正在转写…';
  try {
    const result = await api('/asr', 'POST', wav, {headers: {'Content-Type': 'audio/wav', 'X-Generation': String(gen)}, signal: epoch.abort.signal});
    if (!epoch.valid(gen)) return;
    // Keep the full transcript visible. TTS has a separate 300-character boundary.
    $('transcript').value = result.text; render('ready'); $('record-hint').textContent = '本轮转写完成。';
    message(result.text ? '文字已就绪，可以编辑后回读。' : '没有识别到文字，请重新录音。');
  } catch (error) { failed(error, gen); }
}
async function speak(preview = false, explicitText = null) {
  if (!connected || !appliedTts || (preview && dirty) || delayBusy || ['listening','processing','speaking'].includes(phase)) return;
  const text = preview ? '你好，我是 Gork。这是当前音色的试听。' : (explicitText ?? $('transcript').value.trim());
  if (!text || Array.from(text).length > 300) { message('回读内容需要 1–300 字，请先编辑。', true); return; }
  manualPreview = false; render('processing');
  if (!preview && explicitText === null) addMessage('user', text);
  let gen;
  // Resume inside the click gesture so delayed network audio is playable.
  localStop(); const audio = new AudioContext(); context = audio;
  const resumed = audio.resume();
  try {
    gen = epoch.next();
    await api('/begin', 'POST', {generation: gen, reuse_turn: turnReady}, {signal: epoch.abort.signal});
    if (!epoch.valid(gen)) return;
    turnReady = true;
    await resumed; render('processing');
    let spoken = text;
    if (!preview && explicitText === null && $('interaction-mode').value === 'answer') {
      message('正在请求回答；内容仅发送给已配置的文字回答服务。');
      const result = await api('/answer', 'POST', {generation: gen, text,
        ...(answerSpeechContinuity?{speech_pending:$('auto-read').checked}:{})}, {signal: epoch.abort.signal});
      if (!epoch.valid(gen)) return;
      if('interaction_expression' in result)answerMotion=result.interaction_expression||null;
      spoken = result.text; addMessage('assistant', spoken); render('processing');
      if (!$('auto-read').checked || Array.from(spoken).length > 300) {
        await state('idle',gen);
        if(!epoch.valid(gen))return;
        localStop(); render('ready');
        message(Array.from(spoken).length > 300 ? '回答已完整显示，超过 300 字未自动朗读；可复制片段后朗读。' : '回答已显示；自动朗读已关闭。');
        return;
      }
    }
    message('正在合成完整语音，不会自动重复提交。');
    const bytes = await api('/tts', 'POST', {generation: gen, text: spoken}, {signal: epoch.abort.signal, audio: true});
    if (!epoch.valid(gen)) return;
    const buffer = await audio.decodeAudioData(bytes);
    if (!epoch.valid(gen)) return;
    playback = audio.createBufferSource(); playback.buffer = buffer; playback.connect(audio.destination);
    playback.onended = () => {
      if (!epoch.valid(gen)) return;
      localStop(); answerMotion=null; render('ready'); message('回读完成。可以修改文字，或开始新一轮。');
      const endGen = epoch.next();
      api('/stop', 'POST', {generation: endGen}).catch(error => failed(error, endGen));
    };
    playback.start(); render('speaking'); message('电脑正在播放；“停止”会立即静音。');
    await state('speaking', gen);
  } catch (error) { failed(error, gen); }
}
async function displayComposerText() {
  const original = $('transcript').value.trim(), target = $('bubble-target').value;
  const answerMode = $('interaction-mode').value === 'answer';
  if (!original || !workspace || (target === 'watch' && !robotConnected) || (answerMode && !connected) || outputPending) return;
  if (!answerMode && target === 'watch' && (Array.from(original).length > 24 || new TextEncoder().encode(original).length > 72)) {
    message('Watch 文字最多 24 字、72 字节，请缩短后发送。', true); return;
  }
  outputPending = true; render(); addMessage('user', original);
  let gen;
  try {
    gen = answerMode ? await begin() : epoch.next();
    let text = original;
    if (answerMode) {
      message('正在获取 AI 回答，回答不会自动截断。');
      text = (await api('/answer', 'POST', {generation:gen, text:original}, {signal:epoch.abort.signal})).text;
      if (!epoch.valid(gen)) return;
      addMessage('assistant', text);
    }
    if (target === 'watch' && (Array.from(text).length > 24 || new TextEncoder().encode(text).length > 72)) {
      message('文字已显示在会话中，但超过 Watch 的 24 字或 72 字节限制，未发送到任何小人；请缩短文字。', true); return;
    }
    const result = await api('/character/bubble', 'POST', {text, target}, {signal:epoch.abort.signal});
    if (!epoch.valid(gen)) return;
    characterResult(result);
    const desktopOk = !result.desktop?.requested || result.desktop.accepted;
    const watchOk = !result.watch?.requested || result.watch.accepted;
    message(desktopOk && watchOk ? '文字已发送到所选小人；Watch 实屏效果请以设备为准。' :
      `文字未完整送达：${$('character-result').textContent}`, !(desktopOk && watchOk));
  } catch (error) {
    if (answerMode) failed(error, gen);
    else if (error.name !== 'AbortError' && epoch.valid(gen)) message(error.message || '文字发送失败。', true);
  } finally { outputPending = false; render(); }
}
async function speakOnWatch() {
  const original = $('transcript').value.trim(), answerMode = $('interaction-mode').value === 'answer';
  if (!watchSpeechSync) { message('当前 Gork 后端尚不支持文字与朗读同步，请从托盘退出后重新打开。', true); return; }
  if (!original || !connected || !appliedTts || !workspace || !robotConnected || delayBusy) return;
  delayBusy = true; composerWatchAudio = true; composerWatchProgress = '';
  render('processing'); addMessage('user', original);
  let gen;
  try {
    gen = await begin();
    let text = original;
    if (answerMode) {
      message('正在获取 AI 回答。');
      const answer=await api('/answer', 'POST', {generation:gen, text:original, watch_speech:true,
        ...(answerSpeechContinuity?{speech_pending:true}:{})}, {signal:epoch.abort.signal});
      text=answer.text;
      if (!epoch.valid(gen)) return;
      if('interaction_expression' in answer)answerMotion=answer.interaction_expression||null;
      render();
      addMessage('assistant', text);
    }
    if (!text || Array.from(text).length > 300) throw new Error('文字超过 300 字，已保留在会话中，未合成或发送到 Watch。');
    message('正在合成完整语音；新版 Watch 可在小人页朗读，旧版请保持 Audio test 页面。');
    const wav = await api('/tts', 'POST', {generation:gen, text, watch_speech:true}, {signal:epoch.abort.signal, audio:true});
    if (!epoch.valid(gen)) return;
    if (wav.byteLength > 484096) throw new Error('合成音频超过 Watch 的 10 秒上限，未发送到设备。');
    const audioOptions = {headers:{'Content-Type':'audio/wav', 'X-Generation':String(gen)}, signal:epoch.abort.signal};
    const job = await api('/device/audio/speech', 'POST', wav, audioOptions);
    if (!epoch.valid(gen)) return;
    await waitAudio(job.job_id, gen, 'played');
    if (epoch.valid(gen)) {
      await state('idle',gen);
      if(!epoch.valid(gen))return;
      answerMotion=null;
      render('ready');
      message(`Watch 报告播放完成${job.gain_db > 0 ? ` · 朗读增强 +${job.gain_db} dB` : ''}；实际听感请以设备为准。`);
    }
  } catch (error) { failed(error, gen); }
  finally { delayBusy = false; composerWatchAudio = false; composerWatchProgress = ''; render(); }
}
function submitComposer() {
  const output = $('output-mode').value;
  if (output === 'bubble') return displayComposerText();
  if (output === 'watch-audio') return speakOnWatch();
  return speak();
}
async function refresh() {
  if (healthPolling) return;
  healthPolling = true;
  try {
    const data = await api('/health'); suggestedAddress = data.device_address;
    const lastVoice=data.speech_output?.last;
    if(lastVoice?.rendered)debugConsole.push('TTS',`${lastVoice.mode==='cloud'?'云端':'本地'}音色：${lastVoice.rendered}`,false,'voice');
    answerMotion=data.interaction_expression||data.answer_expression||null;
    if(answerMotion)manualPreview=false;
    // These flags are set only after this window successfully acquires its session.
    // Health is public capability/status data; it has no workspace ownership field.
    const watchReady=connected&&workspace&&!dirty&&!connectionPending&&$('answer-consent').checked&&
      ($('asr').value!=='cloud'||$('audio-consent').checked)&&($('tts').value!=='cloud'||$('text-consent').checked);
    window.GorkNetworkUI?.update(data.robot?.network,data.watch_dialogue,api,data.answer,data.answer_setup,
      {ready:watchReady,key:JSON.stringify([appliedTts,$('asr').value,data.answer?.model,data.answer_setup?.revision])});
    watchChat.consume(data.watch_dialogue);
    watchDelegated = data.watch_dialogue?.enabled === true;
    if(data.watch_dialogue?.enabled && Number.isInteger(data.watch_dialogue.generation)) epoch.value=Math.max(epoch.value,data.watch_dialogue.generation);
    const runningVersion = data.version ? `v${data.version}` : '未知';
    $('desktop-version').textContent = runningVersion;
    $('header-version').textContent = runningVersion;
    watchSpeechSync = data.watch_speech_sync === true;
    answerSpeechContinuity=data.answer_speech_continuity===true;
    startupVoice.enabled = data.auto_connect_voice !== false;
    if (!startupVoice.enabled) { clearStartupVoiceTimer(); startupVoice.done = true; }
    $('service-url').textContent = data.voice_url;
    const service = data.voice_service || {};
    voiceHealthFailures = data.voice_error ? voiceHealthFailures + 1 : 0;
    const errorCode = /^[A-Z][A-Z0-9_]{0,39}$/.test(data.voice_error?.code || '') ? data.voice_error.code : '检查失败';
    const nextVoiceState = data.voice_error
      ? voiceHealthFailures >= 2 ? 'unavailable' : voiceHealthState
      : data.voice?.ready ? 'ready' : 'loading';
    $('voice-status').textContent = data.voice_error
      ? voiceHealthFailures >= 2 ? '暂不可用' : voiceHealthState === 'ready' ? '在线' : '检查中'
      : '在线';
    $('engine-status').textContent = data.voice_error ? data.voice_error.message : `本地引擎：${data.voice.ready ? '已就绪' : '正在加载或尚未就绪'}；云端能力以服务配置为准。`;
    if (nextVoiceState && nextVoiceState !== voiceHealthState) {
      debugConsole.push('SERVICE', nextVoiceState === 'unavailable' ? `语音健康检查连续失败（${errorCode}）`
        : nextVoiceState === 'ready' ? '语音服务就绪' : '语音模型加载中');
      voiceHealthState = nextVoiceState;
    }
    serviceStarting = service.mode === 'starting';
    $('voice-lifecycle').textContent = serviceStarting ? '后台启动中…可留在此页面等待。' :
      data.voice_error ? (service.error || (service.owned ? '托管进程仍在运行，健康检查未通过。' : '服务暂不可用，可点击启动 / 重试。')) :
      service.owned ? '由 Gork 托管 · 退出控制台时关闭' : '复用已运行的服务 · 退出控制台不会关闭它';
    const voiceCatalogue = caps => JSON.stringify([caps?.tts?.speakers,caps?.cloud?.voices,caps?.cloud?.request_voice]);
    if (data.capabilities && voiceCatalogue(data.capabilities) !== voiceCatalogue(capabilities)) {
      capabilities = data.capabilities; fillVoices();
    }
    externalProtocol = !!data.external_protocol; externalPresentation = data.external_presentation || null;
    paintRobot(data.robot);
    const answer = data.answer || {enabled:false, reason:'未配置回答服务；当前为跟读/朗读模式'};
    $('answer-option').disabled = !answer.enabled;
    $('answer-option').textContent = answer.enabled ? 'AI 回答' : 'AI 回答（未配置）';
    if (!answer.enabled && $('interaction-mode').value === 'answer') $('interaction-mode').value = 'read';
    render();
    if (data.capabilities && data.capabilities.protocol_version !== 1) message('接口协议版本不兼容，请更新独立语音服务。', true);
    if (startupVoice.enabled && !startupVoice.done && !connected && !connectionPending) {
      const ready = !data.voice_error && data.voice && data.voice.ready !== false;
      scheduleStartupVoice(ready ? 0 : 1000);
    }
  } catch (error) {
    $('desktop-version').textContent = '无法读取';
    $('header-version').textContent = '版本无法读取';
    $('voice-status').textContent = '工作台断开'; failed(error);
    scheduleStartupVoice(1000);
  } finally { healthPolling = false; }
}
function fillVoices() {
  const cloud = $('tts').value === 'cloud';
  $('voice-speed').disabled = cloud;
  $('voice-speed').value = cloud ? '1' : String(savedSpeech.speed);
  if (!capabilities) return;
  const list = cloud ? capabilities.cloud?.voices || [] : capabilities.tts?.speakers || [];
  const select = $('voice-select');
  select.replaceChildren();
  for (const item of list) select.add(new Option(item.label, String(item.id)));
  const desired = String(cloud ? savedSpeech.cloud_voice : savedSpeech.speaker_id);
  if (list.some(item => String(item.id) === desired)) select.value = desired;
  select.disabled = !list.length;
  $('voice-speed').disabled = cloud;
  $('voice-speed').value = cloud ? '1' : String(savedSpeech.speed);
  $('voice-hint').textContent = cloud ? (capabilities.cloud?.request_voice ?
    '云端试听会上传固定示例文字并可能计费；当前接口仅支持 1.0×。' :
    '当前运行的是旧语音服务，仅提供默认音色；更新服务后可选择更多音色。') :
    '本地合成，不上传文字。选择音色后点击应用设置，再试听。';
}
function speechSettings() {
  const cloud = $('tts').value === 'cloud';
  return {speaker_id: cloud ? Number(savedSpeech.speaker_id) : Number($('voice-select').value || 3),
    cloud_voice: cloud ? $('voice-select').value || 'Cherry' : savedSpeech.cloud_voice,
    speed: cloud ? 1.0 : Number($('voice-speed').value || 1)};
}
function paintRobot(robot) {
  robotConnected = Boolean(robot.connected);
  robotRoute = robotConnected ? robot.network?.route || '' : '';
  const bleConnected = robot.network ? Boolean(robot.network.ble_connected) : robotConnected;
  const operationError = robot.operation_error ?? robot.error;
  const bleError = robot.ble_error || '';
  debugConsole.push('DEVICE', robotConnected ? 'StopWatch 已连接' : 'StopWatch 未连接', false, 'connection');
  debugConsole.push('DEVICE', operationError ? '设备操作异常；展开设备诊断查看' : robot.receipt ? '已收到设备回执（不代表实屏/发声验收）' : '等待设备回执', Boolean(operationError), 'operation');
  debugConsole.push('BLE', bleError ? '蓝牙连接异常；展开设备诊断查看' : bleConnected ? '蓝牙已连接' : '蓝牙未连接', Boolean(bleError), 'connection');
  $('robot-status').textContent = bleConnected ? '已连接' : '未连接';
  $('receipt').textContent = operationError ? '最近设备操作未完成；详情见下方诊断。' : robot.receipt ? `最近设备回执：${robot.receipt}` : '尚无设备操作回执';
  $('watch-diagnostics').textContent = [operationError && `设备操作：${operationError}`, bleError && `蓝牙连接：${bleError}`, robot.network?.error && `Wi-Fi：${robot.network.error}`].filter(Boolean).join('\n') || (robot.receipt ? `最近回执：${robot.receipt}` : '暂无设备回执。');
  $('unpair').disabled = !workspace || !robot.enabled;
  render();
}
async function previewSound() {
  stopPreview(); const serial = previewSerial;
  try {
    const bytes = await api(`/sounds/${$('sound-select').value}/preview`, 'GET', undefined, {audio: true});
    if (serial !== previewSerial) return;
    await previewPlayer.play(bytes, () => { render(); message('电脑试听完成；未向设备发送命令。'); });
    render(); message('电脑正在试听内置声音样本。');
  } catch (error) { stopPreview(); message(error.message || '电脑试听失败。', true); }
}
async function deviceSound(method, path, body) {
  try {
    const result = await api(path, method, body);
    const eventNames = {128:'已接受',129:'正在播放',130:'播放完成',131:'已停止',132:'状态已更新'};
    const label = result.event_name || eventNames[result.event] || result.status || '已完成';
    $('receipt').textContent = `声音回执 ${label}`;
    message(method === 'DELETE' ? '已向设备发送停止命令。' : '设备声音命令已收到有效回执；实际声音请以设备为准。');
    return result;
  } catch (error) { message(error.message, true); }
}
function delayStatus(value) {
  const names = {starting:'正在建立音频会话',armed:'设备已 ARM，请按住 A',recording:'设备正在录音',receiving:'设备 → 电脑传输',received:'接收完成',sending:'电脑 → 设备传输',ready:composerWatchAudio ? '语音已传完，正在显示文字' : '音频已传完，准备播放',playing:'设备报告开始播放',played:'设备报告播放结束',cancelled:'已取消',error:'失败'};
  const percent = value.total ? Math.min(100, value.bytes * 100 / value.total) : 0;
  $('delay-progress').value = percent;
  const speed = value.rate ? ` · ${Math.round(value.rate)} B/s` : '';
  const codec = value.codec === 'opus' ? 'Opus' : value.codec === 'pcm16' ? 'PCM' : '格式待协商';
  const compression = value.codec === 'opus' && value.source_bytes
    ? ` · 原始 ${Math.round(value.source_bytes / 1024)} KB`
    : '';
  const gain = value.gain_db > 0 ? ` · 朗读增强 +${value.gain_db} dB` : '';
  $('delay-status').textContent = `${names[value.stage] || value.stage} · ${codec} ${value.bytes || 0}/${value.total || '?'} bytes${compression}${gain} · ${percent.toFixed(1)}%${speed}`;
  const summary = `${names[value.stage] || '设备音频处理中'} · ${codec} · ${Math.floor(percent / 10) * 10}%`;
  debugConsole.push('AUDIO', summary, value.stage === 'error');
  if (composerWatchAudio && summary !== composerWatchProgress) {
    composerWatchProgress = summary;
    message(`Watch 朗读：${summary}`);
  }
}
async function waitAudio(jobId, gen, expectedStage) {
  while (epoch.valid(gen)) {
    const value = await api('/device/audio'); delayStatus(value);
    if (value.job_id !== jobId) throw new Error('设备音频任务已被替换');
    if (!value.running) {
      if (value.stage === 'cancelled') throw new Error('设备音频任务已取消');
      if (value.stage === 'error' || value.error)
        throw new Error(value.error || 'Watch 音频任务失败，未收到成功回执；请打开设备的 Audio test 页面后重试');
      if (value.stage !== expectedStage)
        throw new Error(`设备音频任务意外结束（${value.stage || '未知状态'}），尚未收到${expectedStage === 'played' ? '播放完成' : '录音接收完成'}回执`);
      return value;
    }
    await new Promise(resolve => setTimeout(resolve, 300));
  }
  throw new DOMException('旧操作', 'AbortError');
}
async function playOnPc(bytes, gen) {
  const audio = new AudioContext(); context = audio; await audio.resume();
  const buffer = await audio.decodeAudioData(bytes); if (!epoch.valid(gen)) return;
  playback = audio.createBufferSource(); playback.buffer = buffer; playback.connect(audio.destination);
  const active = playback; active.onended = () => { if (playback === active) playback = null; };
  active.start(); render('speaking'); message('电脑正在播放设备录音；“停止”会立即静音。');
  while (epoch.valid(gen) && playback === active) await new Promise(resolve => setTimeout(resolve, 100));
  if (epoch.valid(gen)) { localStop(); render('ready'); }
}
async function delayedAudio() {
  let gen;
  try {
    delayBusy = true; render('processing'); gen = await begin();
    const mode = $('delay-mode').value;
    const job = await api('/device/audio/record', 'POST', {echo:false});
    message('设备已准备录音；请在 Audio test 页按住 A，说完松开。');
    await waitAudio(job.job_id, gen, 'received');
    const wav = await api(`/device/audio/result/${job.job_id}`, 'GET', undefined, {audio:true});
    if (mode === 'device-pc') await playOnPc(wav, gen);
    else {
      render('processing'); message('设备录音已接收，正在识别。');
      const asr = await api('/asr', 'POST', wav, {headers:{'Content-Type':'audio/wav','X-Generation':String(gen)},signal:epoch.abort.signal});
      let text = asr.text;
      if ($('interaction-mode').value === 'answer') text = (await api('/answer','POST',{generation:gen,text},{signal:epoch.abort.signal})).text;
      if (Array.from(text).length > 300) throw new Error('处理结果超过 300 字，未合成或发送；请改用电脑输出');
      $('transcript').value = text; render('processing');
      const reply = await api('/tts','POST',{generation:gen,text},{signal:epoch.abort.signal,audio:true});
      const output = await api('/device/audio/play','POST',reply,{headers:{'Content-Type':'audio/wav'}});
      await waitAudio(output.job_id, gen, 'played');
    }
    if (epoch.valid(gen)) { render('ready'); message('延迟音频任务完成；实际听感请以播放端为准。'); }
  } catch (error) { failed(error, gen); }
  finally { delayBusy = false; render(); }
}
async function connect(replace = false, {startup = false} = {}) {
  if (connectionPending) return;
  if (replace && !confirm('接管会使已有语音会话失效。确认接管？')) return;
  if (!startup) cancelStartupVoice();
  connectionPending = true; localStop(); epoch.next(); $('connect').disabled = true; render();
  try {
    await api('/session', 'POST', {replace}); epoch.value = 0; connected = true; workspace = true; dirty = true; appliedTts = ''; turnReady = false;
    $('takeover').hidden = true;
    await apply();
    $('record-hint').textContent = '准备好时，开始录音。';
    return {ok:true};
  } catch (error) {
    if (error.code === 'SESSION_BUSY' || error.code === 'WORKSPACE_BUSY') $('takeover').hidden = false;
    if (!startup) failed(error);
    return {ok:false, error};
  }
  finally {
    connectionPending = false; $('connect').disabled = false; render();
    if (connected && !dirty) await refresh();
  }
}
async function apply(revoking = false) {
  const routing = {asr: $('asr').value, tts: $('tts').value, allow_audio_upload: $('audio-consent').checked, allow_text_upload: $('text-consent').checked};
  if ((routing.asr === 'cloud' && !routing.allow_audio_upload) || (routing.tts === 'cloud' && !routing.allow_text_upload)) { message('请单独勾选所选云端路径的上传许可，或切回本地。', true); return; }
  localStop(); const gen = epoch.next();
  try {
    const speech = speechSettings();
    await api('/settings', 'PATCH', {generation: gen, routing, allow_answer_upload: $('answer-consent').checked, sound_target:$('output-mode').value==='watch-audio'?'watch':'pc', speech: revoking ? null : speech});
    if (!epoch.valid(gen)) return;
    if (!revoking) savedSpeech = {...speech, speed: routing.tts === 'cloud' ? savedSpeech.speed : speech.speed};
    try {
      window.localStorage?.setItem('gork.speech', JSON.stringify(savedSpeech));
      for (const id of ['asr','tts']) window.localStorage?.setItem('gork.' + id, routing[id]);
    } catch {}
    dirty = Boolean(revoking); appliedTts = routing.tts; render('idle'); $('settings-status').textContent = `${routing.asr === 'local' ? '本地' : '云端'} / ${routing.tts === 'local' ? '本地' : '云端'} · 已应用`;
    if (revoking) { $('settings-status').textContent = '上传许可已撤销 · 音色草稿仍需保存'; message('上传许可已撤销，相关路径已停止。'); }
    else message('设置已应用。新请求使用新路径，旧结果不会播放。');
    refreshVoiceLibrary();
  } catch (error) { appliedTts = ''; failed(error, gen); }
}
async function release() {
  localStop(); epoch.next(); connected = false; render('idle');
  try { await api('/voice/session', 'DELETE'); message('已释放语音会话；角色和 StopWatch 控制权保留。'); } catch (error) { message(error.message, true); }
}
async function acquireWorkspace(replace = false) {
  if (replace && !confirm('接管会使另一窗口的操作失效。确认接管工作台？')) return false;
  try {
    const result = await api('/workspace', 'POST', {replace}); workspace = true;
    if (Number.isInteger(result.generation)) epoch.value = Math.max(epoch.value, result.generation);
    $('character-status').textContent = result.voice_connected ? '工作台与语音已连接' : '工作台控制中';
    $('workspace-takeover').hidden = true; $('codex-takeover').hidden = true; render(); refreshCodex(); message('已取得工作台控制权；语音服务仍按需连接。');
    return true;
  } catch (error) {
    if (error.code === 'WORKSPACE_BUSY') { $('workspace-takeover').hidden = false; $('codex-takeover').hidden = false; message('另一窗口正在控制；如需接管，请点击“接管工作台”。', true); }
    else message(error.message, true);
    return false;
  }
}

// Business content stays in this page's memory; never send it to the status log.
let costBusy = false, costPage = 1, costTotal = 0;
let codexLoaded = false, codexPending = false, codexEnabled = false, codexFailure = '';
const codexLabels = {disabled:'已关闭', connecting:'连接中', available:'可用', partial:'部分可用',
  stale:'已过期', unavailable:'不可用', no_windows:'无窗口', cli_missing:'缺少 CLI',
  api_key:'API Key 模式', unsupported_account:'账号不支持', not_logged_in:'未登录',
  unsupported_rpc:'接口不支持', auth_failed:'认证失败', running:'正在执行',
  waiting_approval:'等待确认', waiting_input:'等待补充信息', turn_completed:'本轮结束',
  failed:'本轮失败', interrupted:'已中断', jsonl:'本机会话日志', hook:'已信任 hook'};
const codexLabel = value => codexLabels[value] || '未知';
function codexText(parent, lines, empty) {
  parent.replaceChildren();
  if (!lines.length) { parent.textContent = empty; return; }
  for (const line of lines) { const row = document.createElement('p'); row.textContent = line; parent.append(row); }
}
function paintCodex(data) {
  codexEnabled = data.enabled === true;
  if (!codexLoaded) {
    $('codex-mode').value = data.mode;
    $('codex-target').value = data.target;
    $('codex-sound').checked = data.sound;
    $('codex-sound-target').value = data.sound_target;
    $('codex-threshold').value = data.threshold;
    $('codex-ring-mode').value = data.ring_mode;
    $('codex-drop-step').value = data.drop_step ?? 2;
    $('codex-drop-animation').checked = data.drop_animation !== false;
    codexLoaded = true;
  }
  if (!codexPending) $('codex-enable').checked = data.enabled;
  $('codex-status').textContent = !data.enabled ? '监测已关闭；下次启动仍默认关闭。' :
    `任务通道：${codexLabel(data.task_status)} · 额度通道：${codexLabel(data.quota_status)}${data.quota_error ? ' · ' + data.quota_error : ''}`;
  if (codexFailure) $('codex-status').textContent = `设置未保存：${codexFailure}`;
  $('codex-capability').textContent = '本机会话日志：明确的轮次开始/结束；只读有界尾部无法重建开启前较早开始的长轮次，等待下一轮。审批状态需已审核信任的 hook。';
  const previousThread = $('codex-thread').value || data.thread_id || '';
  $('codex-thread').replaceChildren(new Option('请选择任务', ''));
  for (const item of data.threads || []) $('codex-thread').add(new Option(`${item.label} · ${codexLabel(item.status)} · ${codexLabel(item.source)}`, item.thread_id));
  if (previousThread && !Array.from($('codex-thread').options).some(x => x.value === previousThread))
    $('codex-thread').add(new Option(`指定任务 ${previousThread.slice(0, 8)} · 未观察到`, previousThread));
  $('codex-thread').value = previousThread;
  codexText($('codex-threads'), (data.threads || []).map(x => `${x.label} · ${codexLabel(x.status)} · ${codexLabel(x.source)} · ${x.last_seen || '时间未知'}`), '暂无已观察任务。');
  codexText($('codex-history'), (data.history || []).map(x => `${x.at} · ${x.message} · 桌面 ${x.delivery.desktop} / Watch ${x.delivery.watch} / 声音 ${x.delivery.sound}`), '暂无提醒。');
  const previousBucket = $('codex-bucket').value || data.bucket_id || '';
  const buckets = data.quota?.buckets || {};
  $('codex-bucket').replaceChildren(new Option('自动选择第一个额度桶', ''));
  for (const [id, item] of Object.entries(buckets)) $('codex-bucket').add(new Option(item.name || id, id));
  $('codex-bucket').value = previousBucket in buckets ? previousBucket : '';
  const selected = buckets[$('codex-bucket').value] || Object.values(buckets)[0];
  const rows = selected?.windows?.map((window, index) => {
    const value = window.remaining_percent == null ? '未知' : `${window.remaining_percent}%`;
    const reset = window.resets_at ? new Date(window.resets_at * 1000).toLocaleString() : '未知';
    return `${window.name || `窗口 ${index + 1}`}：剩余 ${value} · 重置 ${reset}`;
  }) || [];
  codexText($('codex-quota'), rows, '无可用额度窗口。');
  if (data.quota?.sampled_at) {
    const sample = document.createElement('small'); sample.textContent = `采样 ${new Date(data.quota.sampled_at).toLocaleString()}${data.quota.stale ? ' · 已过期，等待刷新确认' : ''}`;
    $('codex-quota').append(sample);
  }
}
async function refreshCodex() {
  if (codexPending) return;
  try { paintCodex(await api('/codex/sentinel')); }
  catch (error) { $('codex-status').textContent = `Codex 状态暂不可读取：${error.message}`; }
}
async function applyCodex() {
  if (codexPending) return;
  codexPending = true;
  $('codex-apply').disabled = true;
  let failure = '';
  try {
    if (!workspace) {
      if (!await acquireWorkspace()) throw new Error('另一窗口可能正在控制。请使用本页“接管工作台”或先取得控制权。');
    }
    const values = {enabled:$('codex-enable').checked, mode:$('codex-mode').value,
      thread_id:$('codex-mode').value === 'specific' ? $('codex-thread').value : '',
      target:$('codex-target').value, sound:$('codex-sound').checked,
      sound_target:$('codex-sound-target').value, threshold:Number($('codex-threshold').value),
      bucket_id:$('codex-bucket').value, ring_mode:$('codex-ring-mode').value,
      drop_step:Number($('codex-drop-step').value), drop_animation:$('codex-drop-animation').checked};
    let data;
    try { data = await api('/codex/sentinel', 'PUT', values); }
    catch (error) {
      if (error.code !== 'WORKSPACE_INVALID') throw error;
      workspace = false; render();
      if (!await acquireWorkspace()) throw new Error('工作台控制权已失效。请使用本页“接管工作台”后重试。');
      data = await api('/codex/sentinel', 'PUT', values);
    }
    codexFailure = '';
    codexLoaded = false; paintCodex(data);
  } catch (error) { failure = error.message; codexFailure = failure; }
  finally { codexPending = false; $('codex-apply').disabled = false; await refreshCodex(); if (failure) $('codex-status').textContent = `设置未保存：${failure}`; }
}
$('codex-enable').onchange = applyCodex;
$('codex-apply').onclick = applyCodex;
$('codex-drop-preview').onclick = async () => {
  if (!window.gorkDesktop?.previewQuotaDrop) {
    $('codex-status').textContent = '请在 Electron 桌面客户端中试运行小人动效。';
    return;
  }
  try {
    await window.gorkDesktop.previewQuotaDrop(Number($('codex-drop-step').value), $('codex-drop-animation').checked);
    $('codex-status').textContent = '本机预览已开始；请查看桌面小人。';
  } catch (error) { $('codex-status').textContent = `试运行失败：${error.message}`; }
};
$('codex-acquire').onclick = () => acquireWorkspace();
$('codex-takeover').onclick = () => acquireWorkspace(true);
$('codex-refresh').onclick = async () => {
  try {
    if (!workspace) { await acquireWorkspace(); if (!workspace) return; }
    paintCodex(await api('/codex/quota/refresh', 'POST'));
    $('codex-status').textContent = '额度刷新已加入同一请求；请稍候。';
  }
  catch (error) { $('codex-status').textContent = error.message; }
};
let sentinelPending = false, sentinelLoaded = false, sentinelProjectPage = 1, sentinelProjectTotal = 0, sentinelSelectedTaskId = '';
function sentinelSpecificVisibility() {
  $('sentinel-specific').hidden = $('sentinel-mode').value !== 'specific';
}
function paintSentinel(data) {
  sentinelEnabled = data.enabled === true;
  if (!sentinelLoaded) {
    $('sentinel-source').value = data.source || 'legacy';
    $('sentinel-source').disabled = !data.source;
    $('sentinel-source-note').textContent = data.source ? `当前来源：${data.source === 'astra' ? '智算 Astra' : '原版造价智算'}。选择后应用设置，首次连接不补播历史任务。` : '当前后台尚未支持 Astra 来源，请从托盘退出并重开 Gork 控制台。';
    $('sentinel-mode').value = data.mode;
    $('sentinel-target').value = data.target;
    $('sentinel-sound').checked = data.sound;
    $('sentinel-sound-kind').value = data.sound_kind || 'speech';
    $('sentinel-sound-target').value = data.sound_target || 'pc';
    sentinelSelectedTaskId = data.task_id || '';
    sentinelSpecificVisibility();
    sentinelLoaded = true;
  }
  if (!sentinelPending) $('sentinel-enable').checked = data.enabled;
  const current = data.current, last = data.last_result;
  const activityNames = {running:'正在批量匹配', completed:'本次匹配结束', failed:'本次匹配失败', interrupted:'运行未确认，可能中断', unknown:'尚无可信运行状态'};
  $('sentinel-status').textContent = !data.enabled ? '任务哨兵已关闭；不读取智算任务。' :
    data.connection_error ? `${data.connection_error}最近成功读取：${data.last_success_at || '无'}。` :
    data.deferred ? `任务已变化，提醒暂缓：${data.deferred.reason || '排队等待发送'}；空闲后自动提示。` :
    current?.activity.status === 'running' ? `正在关注：${current.task_name || current.task_id} · ${activityNames[current.activity.status]}` :
    data.history?.length ? `已开启，最近节点：${data.history[0].message}` :
    current ? `正在关注：${current.task_name || current.task_id} · ${activityNames[current.activity.status]}` : '已开启，等待智算任务。';
  const item = current?.activity.status === 'unknown' && data.history?.length ? null : current || last;
  $('sentinel-current').textContent = item ?
    `任务：${item.task_name || item.task_id}\n编号：${item.task_id}\n运行：${activityNames[item.activity.status]}\n任务登记：${item.task_status || '未知'}\n待复核：${item.attention.review_rows ?? '未知'}；预警：${item.attention.warning_rows ?? '未核实'}\n最近读取：${data.last_success_at || '无'}` :
    (data.history?.length ? `最近任务：${data.history[0].task_name || data.history[0].task_id}\n编号：${data.history[0].task_id}\n节点：${data.history[0].message}\n最近读取：${data.last_success_at || '无'}` : '尚无已核实的任务。');
  $('sentinel-history').replaceChildren();
  for (const record of data.history || []) {
    const p = document.createElement('p');
    p.textContent = `${record.at} · ${record.task_name || record.task_id} · ${record.message}（桌面 ${record.delivery.desktop}；Watch ${record.delivery.watch}；声音 ${record.delivery.sound}）`;
    $('sentinel-history').append(p);
  }
  if (!(data.history || []).length) $('sentinel-history').textContent = '暂无提醒。';
  sentinelFace = data.enabled && !data.connection_error ?
    (data.presentation?.expression || (current?.activity.status === 'running' ? 'working' : 'idle')) : 'idle';
  render();
}
async function refreshSentinel() {
  try { paintSentinel(await api('/cost/sentinel')); }
  catch (error) { $('sentinel-status').textContent = `哨兵状态无法读取：${error.message}`; sentinelFace = 'idle'; render(); }
}
async function applySentinel() {
  if (sentinelPending) return;
  sentinelPending = true;
  $('sentinel-apply').disabled = true;
  try {
    if (!workspace) await acquireWorkspace();
    if (!workspace) throw new Error('请先取得工作台控制权。');
    const wasEnabled = sentinelEnabled;
    const enabled = $('sentinel-enable').checked;
    const mode = enabled ? $('sentinel-mode').value : 'auto';
    const task_id = mode === 'specific' ? ($('sentinel-task').value || sentinelSelectedTaskId) : '';
    if (enabled && mode === 'specific' && !task_id) throw new Error('请先选择要关注的任务。');
    const source = $('sentinel-source').value || 'legacy';
    const result = await api('/cost/sentinel', 'PUT', {enabled, mode, task_id,
      ...(!$('sentinel-source').disabled ? {source} : {}),
      target:$('sentinel-target').value, sound:$('sentinel-sound').checked,
      sound_kind:$('sentinel-sound-kind').value,
      sound_target:$('sentinel-sound-target').value});
    if (result.enabled && !wasEnabled) { manualPreview = false; lastFaceState = ''; }
    sentinelLoaded = false; paintSentinel(result);
  } catch (error) { await refreshSentinel(); $('sentinel-status').textContent = `设置未保存：${error.message}`; }
  finally { sentinelPending = false; $('sentinel-apply').disabled = false; }
}
async function loadSentinelProjects(page = 1) {
  try {
    if (!workspace) await acquireWorkspace();
    if (!workspace) return;
    const source = $('sentinel-source').value || 'legacy';
    const version = ++sentinelListVersion;
    const route = $('sentinel-source').disabled ? '/cost/projects' : '/cost/sentinel/projects';
    const result = await api(`${route}?page=${page}&source=${source}`);
    if (source !== $('sentinel-source').value || version !== sentinelListVersion) return;
    sentinelProjectPage = page; sentinelProjectTotal = result.total;
    $('sentinel-page').textContent = `第 ${page} 页 · 共 ${result.total} 项`;
    $('sentinel-project').replaceChildren(new Option('请选择项目', ''));
    $('sentinel-task').replaceChildren(new Option('请选择任务', ''));
    for (const item of result.items) if (item.project_id) $('sentinel-project').add(new Option(item.project_name || item.project_id, item.project_id));
    $('sentinel-status').textContent = `本页已加载 ${result.items.length} 个项目。`;
  } catch (error) { $('sentinel-status').textContent = error.message; }
}
$('sentinel-projects').onclick = () => loadSentinelProjects(1);
$('sentinel-prev').onclick = () => { if (sentinelProjectPage > 1) loadSentinelProjects(sentinelProjectPage - 1); };
$('sentinel-next').onclick = () => { if (sentinelProjectPage * 20 < sentinelProjectTotal) loadSentinelProjects(sentinelProjectPage + 1); };
$('sentinel-project').onchange = async () => {
  sentinelSelectedTaskId = '';
  $('sentinel-task').replaceChildren(new Option('请选择任务', ''));
  const id = $('sentinel-project').value; if (!id) return;
  try {
    const source = $('sentinel-source').value || 'legacy';
    const version = ++sentinelListVersion;
    const route = $('sentinel-source').disabled ? '/cost/projects' : '/cost/sentinel/projects';
    const result = await api(`${route}/${encodeURIComponent(id)}?source=${source}`);
    if (source !== $('sentinel-source').value || id !== $('sentinel-project').value || version !== sentinelListVersion) return;
    for (const item of result.tasks) if (item.task_id) $('sentinel-task').add(new Option(item.task_name || item.task_id, item.task_id));
  } catch (error) { $('sentinel-status').textContent = error.message; }
};
let sentinelListVersion = 0;
$('sentinel-source').onchange = () => {
  sentinelListVersion++; sentinelSelectedTaskId = ''; sentinelProjectPage = 1; sentinelProjectTotal = 0;
  $('sentinel-project').replaceChildren(new Option('请选择项目', ''));
  $('sentinel-task').replaceChildren(new Option('请选择任务', ''));
  $('sentinel-page').textContent = '第 1 页';
  $('sentinel-source-note').textContent = '来源尚未应用。选择跟随方式与输出位置，再点击应用设置。';
  if ($('sentinel-mode').value === 'specific') loadSentinelProjects(1);
};
$('sentinel-task').onchange = () => { sentinelSelectedTaskId = $('sentinel-task').value; };
$('sentinel-mode').onchange = () => { sentinelSpecificVisibility(); if ($('sentinel-mode').value === 'specific') loadSentinelProjects(1); };
$('sentinel-target').onchange = sentinelSpecificVisibility;
$('sentinel-enable').onchange = applySentinel;
$('sentinel-apply').onclick = applySentinel;
let voiceLibraryBusy = false;
function paintVoiceLibrary(data) {
  $('voice-library-status').textContent = `${data.voice_label} · ${data.model} · 已缓存 ${data.ready}/${data.total} 条`;
  if(data.warmup?.state==='generating')$('voice-library-status').textContent+=' · 正在预生成';
  const holder = $('voice-library-items'); holder.replaceChildren();
  for (const item of data.items) {
    const row = document.createElement('div'); row.className = 'voice-library-row';
    const label = document.createElement('span'); label.textContent = `${item.group} · ${item.text}`;
    const state = document.createElement('small'); state.textContent = item.ready ? '已缓存' : '待生成';
    const preview = document.createElement('button'); preview.type = 'button'; preview.textContent = '试听'; preview.disabled = !item.ready;
    preview.onclick = async () => {
      stopPreview(); const serial = previewSerial;
      try {
        const audio = await api(`/character/voice-library/${item.id}/preview`, 'GET', undefined, {audio:true});
        if (serial !== previewSerial) return;
        await previewPlayer.play(audio, () => message('语音库试听完成。'));
        message(`正在电脑试听：${item.text}`);
      } catch (error) { message(error.message, true); }
    };
    const update = document.createElement('button'); update.type = 'button'; update.textContent = item.ready ? '更新' : '生成';
    update.disabled = voiceLibraryBusy;
    update.onclick = () => generateVoiceLibrary(item.id, true);
    row.append(label, state, preview, update); holder.append(row);
  }
  $('voice-library-generate').disabled = voiceLibraryBusy || data.warmup?.state==='generating' || data.ready === data.total;
}
async function refreshVoiceLibrary() {
  try { paintVoiceLibrary(await api('/character/voice-library')); }
  catch (error) { $('voice-library-status').textContent = `语音库读取失败：${error.message}`; }
}
async function generateVoiceLibrary(itemId = '', force = false) {
  if (voiceLibraryBusy) return;
  let failure = '';
  voiceLibraryBusy = true; $('voice-library-generate').disabled = true;
  $('voice-library-status').textContent = '正在用当前音色生成并保存固定短句…';
  try {
    if (!connected) throw new Error('请先在设置页连接语音会话。');
    if (!workspace) throw new Error('请先取得工作台控制权。');
    const result = await api('/character/voice-library/generate', 'POST', {item_id:itemId, force});
    paintVoiceLibrary(result.library);
    message(`已保存 ${result.generated.length} 条当前音色的固定播报。`);
  } catch (error) { failure = error.message; message(error.message, true); }
  finally { voiceLibraryBusy = false; await refreshVoiceLibrary(); if (failure) $('voice-library-status').textContent += ` · 生成中断：${failure}`; }
}
$('voice-library-generate').onclick = () => generateVoiceLibrary();
async function costOperation(run) {
  if (costBusy) return;
  costBusy = true;
  $('cost-feedback').textContent = '正在查询…';
  let gen;
  try {
    if (!workspace) await acquireWorkspace();
    if (!workspace) throw new Error('请先取得工作台控制权。');
    localStop(); turnReady = false;
    gen = epoch.next(); render('processing');
    await run(gen, epoch.abort.signal);
    if (epoch.valid(gen)) $('cost-feedback').textContent = '查询完成；请核对依据。';
  } catch (error) {
    if (gen === undefined || epoch.valid(gen)) $('cost-feedback').textContent = error.message;
  } finally {
    costBusy = false;
    if (gen !== undefined && epoch.valid(gen)) render('idle');
  }
}
async function loadCostProjects(page) {
  return costOperation(async (gen, signal) => {
    const result = await api(`/cost/projects?page=${page}`, 'GET', undefined, {signal});
    if (!epoch.valid(gen)) return;
    costPage = page; costTotal = result.total;
    $('cost-project').replaceChildren();
    $('cost-project').add(new Option('请选择项目', ''));
    for (const item of result.items) if (item.project_id) $('cost-project').add(new Option(item.project_name || item.project_id, item.project_id));
    $('cost-page').textContent = `第 ${page} 页 · 共 ${costTotal} 项`;
  });
}
$('cost-health').onclick = async () => {
  try {
    const result = await api('/cost/health');
    $('cost-status').textContent = `造价智算在线 · ${result.release_version || result.version}`;
  } catch (error) { $('cost-status').textContent = error.message; }
};
$('cost-import').onclick = () => { $('cost-question').value = $('transcript').value; };
$('cost-query').onclick = () => costOperation(async (gen, signal) => {
  const question = $('cost-question').value.trim();
  if (!question) throw new Error('请先输入问题。');
  const allow_ai = $('cost-ai').checked;
  $('cost-ai').checked = false; // one-request permission, not a stored business-upload default
  $('cost-answer').textContent = ''; $('cost-evidence').textContent = ''; $('cost-sources').replaceChildren();
  const result = await api('/cost/query', 'POST', {generation:gen, question, allow_ai}, {signal});
  if (!epoch.valid(gen)) return;
  const kind = result.preset_answer || result.answer_mode === 'curated_demo' ? '预设演示回答（非实时检索）' :
    result.answer_mode === 'local_search' ? '本地依据检索（未调用问答模型）' : `回答类型：${result.answer_mode}`;
  $('cost-evidence').textContent = `${kind} · ${result.evidence_found ? '有依据，仍需人工核对' : '未找到依据，不能据此计价'}`;
  $('cost-answer').textContent = result.answer;
  for (const source of result.sources) {
    const item = document.createElement('article');
    const title = document.createElement('strong'); title.textContent = source.title || source.source_file || source.id || '未命名出处';
    const location = document.createElement('small'); location.textContent = [source.library_name, source.source_file, source.title_path || source.heading, source.authority_level, source.page != null ? `页 ${source.page}` : ''].filter(Boolean).join(' · ');
    const content = document.createElement('p'); content.textContent = source.snippet || '请在造价智算核对原文。';
    item.append(title, location, content); $('cost-sources').append(item);
  }
});
$('cost-stop').onclick = async () => { await stopAll(); $('cost-feedback').textContent = '已停止等待；上游模型可能仍在执行。'; };
$('cost-projects').onclick = () => loadCostProjects(1);
$('cost-prev').onclick = () => { if (costPage > 1) return loadCostProjects(costPage - 1); };
$('cost-next').onclick = () => { if (costPage * 20 < costTotal) return loadCostProjects(costPage + 1); };
$('cost-detail').onclick = () => costOperation(async (gen, signal) => {
  const id = $('cost-project').value;
  if (!id) throw new Error('请选择项目。');
  const result = await api(`/cost/projects/${encodeURIComponent(id)}`, 'GET', undefined, {signal});
  if (epoch.valid(gen)) {
    const project = result.project;
    $('cost-project-result').textContent = `${project.project_name || id}\n项目状态：${project.status_label || project.status || '未提供'}\n更新时间：${project.updated_at || '未提供'}\n\n` +
      (result.tasks.length ? result.tasks.map(task => `${task.task_name || task.task_id} · ${task.status_label || task.status || '未提供'}${task.stage_label ? ' · ' + task.stage_label : ''}`).join('\n') : '暂无业务任务。');
  }
});
$('cost-transfer').onclick = () => {
  const text = $('cost-summary').value.trim();
  if (!text || Array.from(text).length > 300) { $('cost-feedback').textContent = '请确认 1–300 字摘要；不会自动截断。'; return; }
  if (costBusy || ['listening','processing','speaking'].includes(phase)) { $('cost-feedback').textContent = '请先停止当前操作。'; return; }
  $('transcript').value = text; $('interaction-mode').value = 'read';
  location.hash = '#dialogue'; navigate(); render('ready');
  message('已带入摘要，尚未朗读或发送。请选择输出方式后执行。');
};
function characterOptions() {
  const names = [...new Set([...(window.GorkCatalog?.sequences || []).map(item => item.id), 'happy-work'])];
  const select = $('character-expression'), previous=select.value; select.replaceChildren();
  const chinese = {waking:'醒来',searching:'搜索',working:'工作',suspicious:'怀疑',idle:'待机',listening:'聆听',thinking:'思考',happy:'开心',excited:'兴奋',surprised:'惊讶',confused:'疑惑',angry:'生气',sleeping:'睡觉',drowsy:'困倦',love:'喜爱',wink:'眨眼',curious:'好奇',focused:'专注',bored:'无聊',tired:'疲惫',proud:'得意',shy:'害羞',sad:'难过',laughing:'大笑',scared:'害怕',playful:'俏皮',celebrate:'庆祝','happy-work':'开心工作（仅 StopWatch）'};
  for (const name of names) select.add(new Option((chinese[name] || name) + ' · ' + name, name));
  for(const entry of customExpressions)select.add(new Option(entry.name+' · 自定义',entry.id));
  select.value=names.includes(previous)||customExpressions.some(entry=>entry.id===previous)?previous:'idle';
}
async function refreshCustomExpressions(){try{const r=await fetch('/api/motion/expressions');if(!r.ok)return;const library=await r.json();if(!Array.isArray(library.entries))return;customExpressions=library.entries;face?.setLibrary?.(customExpressions);expressionMenu?.setCustomEntries(customExpressions);characterOptions();}catch{}}
function characterTarget() { return $('character-target').value; }
function characterResult(value) {
  const desktop = value.desktop?.requested ? (value.desktop.accepted ? '桌面：已接收' : '桌面：未接收') : '桌面：未发送';
  const watch = value.watch?.requested ? (value.watch.accepted ? `Watch：${value.watch.receipt || '已接收'}` : `Watch：${value.watch.error || '失败'}`) : 'Watch：未发送';
  $('character-result').textContent = `${desktop}；${watch}`;
  return `${desktop}；${watch}`;
}
async function quickExpression(expression, target, mode) {
  if (expressionPending || ['listening','processing','speaking'].includes(phase) || delayBusy || outputPending)
    throw new Error('请先结束当前操作。');
  expressionPending = true;
  const signal = epoch.abort.signal;
  render();
  try {
    if (!workspace) await acquireWorkspace();
    if (!workspace) throw new Error('未取得控制权，请在设置中处理工作台占用。');
    if (signal.aborted) throw new DOMException('操作已取消','AbortError');
    const gen = epoch.value;
    const result = await api('/character','POST',{expression,target,mode},{signal});
    if (!epoch.valid(gen)) throw new DOMException('操作已取消','AbortError');
    if (target !== 'watch' && result.desktop?.accepted) {
      const startedAt = Date.now(); manualPreview = true; manualPreviewUntil = startedAt + 15000;
      characterFace?.set(expression,{mode,startedAt,force:true});
      if(customExpressions.some(entry=>entry.id===expression)&&window.gorkDesktop?.playCustomExpression)await window.gorkDesktop.playCustomExpression(expression,mode);
      else shareAvatarScene(expression,mode,startedAt);
    }
    return characterResult(result);
  } finally { expressionPending=false; render(); }
}
async function previewCharacter() {
  const name = $('character-expression').value;
  if (name === 'happy-work') { message('开心工作包含设备专属纸笔层，请发送到 StopWatch 查看。'); return; }
  const startedAt = Date.now();
  manualPreview = true; manualPreviewUntil = startedAt + 15000; characterFace?.set(name, {mode:$('character-mode').value, startedAt, force:true});
  shareAvatarScene(name, $('character-mode').value, startedAt);
  $('character-status').textContent = `正在本地预览：${name}`;
}
async function playCharacter() {
  const expression = $('character-expression').value, target = characterTarget();
  if (expression === 'happy-work' && target !== 'watch') { message('happy-work 只有 StopWatch 的纸笔层，不能发送到桌面或两端。', true); return; }
  try {
    characterResult(await api('/character', 'POST', {expression, mode:$('character-mode').value, target}));
    if (target !== 'watch') await previewCharacter();
  }
  catch (error) { message(error.message, true); }
}
async function clearBubble() {
  const target = characterTarget();
  try {
    const result = await api('/character/bubble', 'DELETE', {target});
    characterResult(result); render();
  } catch (error) { message(error.message, true); }
}
async function heartbeat() {
    if (!connected || polling) return;
    const tab = client;
  polling = true;
  try { const data = await api('/session', 'GET', undefined, {signal: AbortSignal.timeout(4000)}); if (client === tab) paintRobot(data.robot); }
  catch (error) { if (client === tab) { localStop(); epoch.next(); connected = false; render('idle'); message(`会话连接已失效，已停止本地播放。${error.message}`, true); } }
  finally { polling = false; }
}
async function workspaceHeartbeat() {
  if (!workspace || connected || polling) return;
  polling = true;
  try { const data = await api('/workspace', 'GET', undefined, {signal: AbortSignal.timeout(4000)}); paintRobot(data.robot); }
  catch (error) { workspace = false; render(); message(`工作台控制权已失效。${error.message}`, true); }
  finally { polling = false; }
}
for (const id of ['asr', 'tts', 'audio-consent', 'text-consent', 'answer-consent']) $(id).addEventListener('change', async () => {
  if (consentIds.includes(id)) {
    try { window.localStorage?.setItem('gork.' + id, String($(id).checked)); } catch {}
  }
  dirty = true; $('settings-status').textContent = '有未保存设置 · 当前会话仍使用已应用设置';
  if (consentIds.includes(id) && !$(id).checked) {
    if (id === 'audio-consent') $('asr').value = 'local';
    if (id === 'text-consent') { $('tts').value = 'local'; fillVoices(); }
    if (id === 'answer-consent') $('interaction-mode').value = 'read';
    await stop();
    if (connected) await apply(true);
  }
  render();
});
$('record').onclick = record; $('finish').onclick = finish; $('stop').onclick = stop; $('speak').onclick = submitComposer;
$('voice-preview').onclick = () => speak(true);
$('voice-stop').onclick = stop;
$('voice-start').onclick = async () => {
  serviceStarting = true; render(); $('voice-lifecycle').textContent = '正在启动语音服务…';
  try { await api('/voice-service/start', 'POST'); await refresh(); }
  catch (error) { serviceStarting = false; render(); message(error.message, true); }
};
for (const id of ['voice-select','voice-speed']) $(id).onchange = () => {
  dirty = true; $('settings-status').textContent = '音色设置未应用'; render();
};
$('tts').addEventListener('change', fillVoices);
$('connect').onclick = () => connect(); $('takeover').onclick = () => connect(true); $('release').onclick = release;
$('voice-release').onclick = release; $('workspace-acquire').onclick = () => acquireWorkspace();
$('apply').onclick = () => apply(); $('refresh').onclick = refresh; $('transcript').oninput = () => render();
$('transcript').addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); submitComposer(); } });
$('output-mode').onchange = () => { render(); if(workspace && externalProtocol)api('/external/output','PATCH',{target:$('output-mode').value==='watch-audio'?'watch':'pc'}).catch(error=>message(error.message,true)); }; $('bubble-target').onchange = () => render();
$('interaction-mode').onchange = () => { render(); message($('interaction-mode').value === 'answer' ? '先获取 AI 回答，再按所选方式输出；需已应用独立许可。' : '直接输出原文，不调用回答服务。'); };
$('clear-answer').onclick = async () => { try {
  if (!connected) { message('请先连接语音会话，再开始新会话。',true); return; }
  const cleared = await api('/answer/history', 'DELETE');
  watchChat.clear(cleared);watchRows.clear();
  if (Number.isInteger(cleared.generation)) epoch.value=Math.max(epoch.value,cleared.generation);
  $('chat-log').replaceChildren();message('会话记录与回答上下文已清空。');
} catch (error) { message(error.message, true); } };
$('sound-preview').onclick = previewSound;
$('sound-play').onclick = () => deviceSound('POST', '/device/sound', {sound_id: Number($('sound-select').value)});
$('sound-stop').onclick = () => { stopPreview(); if (workspace && robotConnected) return deviceSound('DELETE', '/device/sound'); };
$('sound-volume').oninput = () => { $('sound-volume-label').textContent = `${$('sound-volume').value}%`; };
$('sound-volume').onchange = () => deviceSound('PUT', '/device/sound/volume', {volume: Number($('sound-volume').value)});
$('delay-start').onclick = delayedAudio;
$('delay-cancel').onclick = stop;
$('global-stop').onclick = stopAll;
$('character-preview').onclick = previewCharacter; $('character-play').onclick = playCharacter;
$('character-idle').onclick = async () => { try { if (workspace) await api('/character', 'DELETE'); manualPreview = false; lastFaceState = ''; render(); $('character-status').textContent = '已返回自动联动'; } catch (error) { message(error.message, true); } };
$('character-expression').onchange = previewCharacter;
$('bubble-clear').onclick = clearBubble;
$('scan').onclick = async () => {
  $('scan').disabled = true; message('扫描蓝牙设备中…');
  try {
    const {devices} = await api('/devices'); $('device').replaceChildren();
    for (const item of devices) $('device').add(new Option(`${item.name} · ${item.address}`, item.address));
    if (devices.some(x => x.address === suggestedAddress)) $('device').value = suggestedAddress;
    $('device').disabled = !devices.length; $('pair').disabled = !devices.length;
    message(devices.length ? '选择设备后连接。已绑定设备无需重开 Pair。' : '未发现设备。请确认 Watch 蓝牙为 ON，待开机广播稳定后重扫；已绑定设备无需清除配对。');
  } catch (error) { message(error.message, true); }
  finally { $('scan').disabled = !workspace; }
};
$('pair').onclick = async () => { $('pair').disabled = true; try { paintRobot(await api('/device', 'POST', {address: $('device').value})); message('蓝牙已连接；回执不等于实屏效果，请看设备。'); } catch (error) { message(error.message, true); } finally { $('pair').disabled = false; } };
$('unpair').onclick = async () => { try { paintRobot(await api('/device', 'DELETE')); } catch (error) { message(error.message, true); } };
window.addEventListener('hashchange',()=>{navigate();if(location.hash==='#external'&&workspace)externalUI.refresh();});
window.addEventListener('blur', () => { if (phase === 'listening' || recordingPending) stop(); });
$('character-acquire').onclick = () => acquireWorkspace();
$('workspace-takeover').onclick = () => acquireWorkspace(true);
window.addEventListener('pagehide', () => { expressionMenu?.dispose(); cancelStartupVoice(); stopPreview(); localStop(); epoch.next(); if (workspace) api('/workspace', 'DELETE', undefined, {keepalive: true}).catch(() => {}); });
if (window.gorkDesktop?.onStopAll) window.gorkDesktop.onStopAll(() => {
  stopPreview(); localStop(); epoch.next(); delayBusy = false; render('idle'); message('已由桌面控制台停止本地录音、播放和在途任务。');
});
expressionMenu = createExpressionMenu(document,{catalog:window.GorkCatalog,renderer:window.GorkAvatar,motion:window.GorkMotionPreview,send:quickExpression});
if(window.GorkAppearance) createAppearancePicker(document,{library:window.GorkAppearance,renderer:window.GorkAvatar,catalog:window.GorkCatalog,storage:debugStorage,bridge:window.gorkDesktop,onChange:value=>{face?.setAppearance(value);expressionMenu.setAppearance(value);}});
refreshCustomExpressions();
window.addEventListener('message',e=>{if(e.origin===location.origin&&e.source===$('motion-editor-frame')?.contentWindow&&e.data?.type==='gork-motion-library-changed')refreshCustomExpressions();});
characterOptions(); fillVoices(); navigate(); render(); refresh(); setInterval(heartbeat, 1000); setInterval(workspaceHeartbeat, 1000);
setInterval(() => { if (watchDelegated || ++healthIdleTicks >= 5) { healthIdleTicks = 0; refresh(); } }, 1000);
refreshSentinel(); setInterval(() => { if (sentinelEnabled) refreshSentinel(); }, 2500);
refreshCodex();
setInterval(() => { if (codexEnabled || location.hash === '#codex') refreshCodex(); }, 2500);
refreshVoiceLibrary();
setInterval(()=>{if(location.hash==='#character'&&!voiceLibraryBusy)refreshVoiceLibrary();},5000);

$('quick-connect').onclick = () => connect();
for (const id of ['auto-read','expression-follow']) $(id).onchange = () => {
  try { window.localStorage?.setItem('gork.' + id, String($(id).checked)); } catch {}
  if (id === 'expression-follow') { manualPreview = false; lastFaceState = ''; }
  render();
};
document.querySelectorAll?.('[data-page-link]').forEach((tab, index, tabs) => {
  tab.addEventListener('keydown', event => {
    let target;
    if (event.key === 'ArrowRight') target = (index + 1) % tabs.length;
    if (event.key === 'ArrowLeft') target = (index + tabs.length - 1) % tabs.length;
    if (event.key === 'Home') target = 0;
    if (event.key === 'End') target = tabs.length - 1;
    if (target !== undefined) { event.preventDefault(); tabs[target].focus(); location.hash = tabs[target].dataset.pageLink; }
  });
});
async function refreshDesktopVisibility() {
  if (!window.gorkDesktop?.getAvatarVisible) return;
  try { $('desktop-visible').checked = await window.gorkDesktop.getAvatarVisible(); $('desktop-visible').disabled = false; $('desktop-hint').textContent = '显示独立桌面窗口'; }
  catch { $('desktop-visible').disabled = true; }
}
$('desktop-visible').onchange = async () => {
  $('desktop-visible').disabled = true;
  try { await window.gorkDesktop.setAvatarVisible($('desktop-visible').checked); }
  catch (error) { message(error.message || '无法切换桌面小人', true); }
  await refreshDesktopVisibility();
};
refreshDesktopVisibility(); setInterval(refreshDesktopVisibility, 2000);

let avatarTopBusy = false;
async function refreshAvatarAlwaysOnTop() {
  if (!window.gorkDesktop?.getAvatarAlwaysOnTop || avatarTopBusy) return;
  try {
    $('desktop-always-on-top').checked = await window.gorkDesktop.getAvatarAlwaysOnTop();
    $('desktop-always-on-top').disabled = false;
    $('desktop-top-hint').textContent = '开启后显示在其他窗口前方，自动记住';
  } catch { $('desktop-always-on-top').disabled = true; }
}
$('desktop-always-on-top').onchange = async () => {
  if (!window.gorkDesktop?.setAvatarAlwaysOnTop) return;
  avatarTopBusy = true;
  $('desktop-always-on-top').disabled = true;
  try { await window.gorkDesktop.setAvatarAlwaysOnTop($('desktop-always-on-top').checked); }
  catch (error) { message(error.message || '无法切换始终置顶', true); }
  finally { avatarTopBusy = false; await refreshAvatarAlwaysOnTop(); }
};
refreshAvatarAlwaysOnTop(); setInterval(refreshAvatarAlwaysOnTop, 2000);

let pendingAvatarScale = null, avatarScaleBusy = false;
async function refreshAvatarScale() {
  if (!window.gorkDesktop?.getAvatarScale || avatarScaleBusy || document.activeElement === $('desktop-size')) return;
  try {
    const scale = await window.gorkDesktop.getAvatarScale();
    if (avatarScaleBusy) return;
    $('desktop-size').value = String(scale); $('desktop-size-value').textContent = `${scale}%`;
    $('desktop-size').disabled = false; $('desktop-size-hint').textContent = '只调整桌面小人，自动记住大小';
  } catch { $('desktop-size').disabled = true; }
}
async function applyAvatarScale() {
  if (avatarScaleBusy || !window.gorkDesktop?.setAvatarScale) return;
  avatarScaleBusy = true;
  try {
    while (pendingAvatarScale !== null) {
      const scale = pendingAvatarScale; pendingAvatarScale = null;
      const actual = await window.gorkDesktop.setAvatarScale(scale);
      if (pendingAvatarScale === null) { $('desktop-size').value = String(actual); $('desktop-size-value').textContent = `${actual}%`; }
    }
  } catch (error) { pendingAvatarScale = null; message(error.message || '桌面小人大小调整失败', true); }
  finally { avatarScaleBusy = false; }
}
$('desktop-size').oninput = () => {
  $('desktop-size-value').textContent = `${$('desktop-size').value}%`;
  pendingAvatarScale = Number($('desktop-size').value); applyAvatarScale();
};
refreshAvatarScale(); setInterval(refreshAvatarScale, 2000);

let bubblePositionBusy = false;
async function refreshBubblePosition() {
  if (!window.gorkDesktop?.getBubblePosition || bubblePositionBusy || document.activeElement === $('desktop-bubble-position')) return;
  try {
    $('desktop-bubble-position').value = await window.gorkDesktop.getBubblePosition();
    $('desktop-bubble-position').disabled = false;
    $('desktop-bubble-hint').textContent = '自动记住；屏幕边缘会调整位置';
  } catch { $('desktop-bubble-position').disabled = true; }
}
$('desktop-bubble-position').onchange = async () => {
  if (!window.gorkDesktop?.setBubblePosition) return;
  bubblePositionBusy = true; $('desktop-bubble-position').disabled = true;
  try { $('desktop-bubble-position').value = await window.gorkDesktop.setBubblePosition($('desktop-bubble-position').value); }
  catch (error) { message(error.message || '气泡位置设置失败', true); }
  finally { bubblePositionBusy = false; $('desktop-bubble-position').blur?.(); await refreshBubblePosition(); }
};
refreshBubblePosition(); setInterval(refreshBubblePosition, 2000);

const externalUI = typeof createExternalUI === 'function' ? createExternalUI({document, api, acquireWorkspace, hasWorkspace:()=>workspace, clipboard:text=>navigator.clipboard.writeText(text)}) : {refresh:async()=>{}};
setInterval(()=>{if(location.hash==='#external'&&workspace)externalUI.refresh();},2500);
