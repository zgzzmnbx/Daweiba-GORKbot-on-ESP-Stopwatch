"""One BLE writer, latest-state wins. Offline robot never blocks PC speech."""
import asyncio
import contextlib
import math
import time
from pathlib import Path
import sys
import uuid

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "tools"))
from stopwatch_ble import (BleExpressionClient, BleConsoleError,
                           EXPRESSIONS as BLE_EXPRESSIONS, known_bond_target,
                           scan_targets, is_custom_command)
from stopwatch_sound import SoundClient
from stopwatch_audio import AudioClient, make_wav, read_wav
from .network_manager import NetworkManager

EXPRESSIONS = {"idle": "idle", "listening": "loop listening",
    "processing": "loop thinking", "speaking": "loop happy", "error": "confused"}
RECONNECT_INITIAL_DELAY = 5
RECONNECT_MAX_DELAY = 30
CONNECTION_POLL_SECONDS = 1


def short_bubble(text):
    # Full ASR/TTS text stays in the PC editor; device receives a labelled preview.
    clean = "".join(c for c in text if c.isprintable() and ord(c) <= 0xFFFF)
    return clean if len(clean) <= 24 else clean[:23] + "…"


def boost_watch_speech(pcm):
    """Compensate for the built-in sounds' separate +9.5 dB codec profile.

    This runs only for synthesized Watch speech, before PCM or Opus encoding.
    Leave full-scale input and silence alone; never clip the output samples.
    """
    samples = np.frombuffer(pcm, dtype="<i2")
    peak = int(np.abs(samples.astype(np.int32)).max(initial=0))
    if not peak or peak >= 30000:
        return pcm, 0.0
    gain = min(3.0, 30000 / peak)
    if gain <= 1.0:
        return pcm, 0.0
    raised = np.rint(samples.astype(np.float32) * gain).astype("<i2")
    return raised.tobytes(), round(20 * math.log10(gain), 1)


class Robot:
    def __init__(self, client=None, scanner=None, sound=None,
                 known_target_factory=None):
        self.client = client or BleExpressionClient()
        self.scanner = scanner
        self.sound = sound or SoundClient()
        self.known_target_factory = known_target_factory or known_bond_target
        self.targets = {}
        self.target = None
        self.enabled = False
        self.generation = 0
        self.revision = 0
        self.flushed_revision = -1
        self.state, self.text = "idle", ""
        self.expression=None
        self.applied_loop=None
        self.receipt, self.error = "", ""
        self.ble_error = ""
        self.reconnects = 0
        self.changed = asyncio.Event()
        self.lock = asyncio.Lock()
        self.worker = None
        self.auto_task = None
        self.maintain_task = None
        self.operation_epoch = 0
        self.reconnect_enabled = False
        self.preferred_address = ""
        self.audio = None
        self.prepared_audio = None
        self.prepared_identity = None
        self.recording_started=None
        self.capture_stopped=None
        self.audio_task = None
        self.audio_job = ""
        self.audio_mode = ""
        self.audio_progress = {"stage": "idle", "bytes": 0, "total": 0, "elapsed": 0, "rate": 0}
        self.audio_result = None
        self.audio_error = ""
        self.audio_gain_db = 0.0
        self.network = NetworkManager(self)
        self.dialogue_pinned = False

    def device_client(self):
        if not self.network.wifi.connected and self.network.router.active!='wifi' and not self.network.router.manual and self.network.router.policy!='wifi_only':return self.client
        try:return self.network.selected()
        except ConnectionError as exc:raise BleConsoleError(str(exc)) from exc

    async def send_expression(self, command, *, restart=False):
        """Preserve an acknowledged custom loop across speech-stage updates.

        All callers hold the device writer lock. A new session/route/generation,
        another expression, failed write or explicit manual click must resend.
        """
        client=self.device_client()
        transport=getattr(client,'writer',None) or getattr(client,'client',None) or client
        identity=(client,transport,getattr(client,'boot',None),getattr(client,'session',None),self.operation_epoch,self.generation)
        custom_loop=command.startswith('loop ') and is_custom_command(command[5:])
        if custom_loop and not restart and self.applied_loop and self.applied_loop[:2]==(identity,command):
            return self.applied_loop[2]
        self.applied_loop=None
        receipt=await client.send_command(command)
        if custom_loop:self.applied_loop=(identity,command,receipt)
        return receipt

    @property
    def device_connected(self):
        try:return self.device_client().connected
        except BleConsoleError:return False

    def start(self):
        self.worker = asyncio.create_task(self.run())
        self.network.start()

    def start_auto_connect(self, preferred_address=""):
        """Start the background connection supervisor for this StopWatch."""
        self.reconnect_enabled = True
        self.preferred_address = preferred_address.strip()
        if self.auto_task is None:
            self.auto_task = asyncio.create_task(
                self._auto_connect(self.preferred_address, self.operation_epoch))
            self._start_maintain(self.preferred_address, self.auto_task)

    def _start_maintain(self, preferred_address, initial=None):
        if self.maintain_task is None or self.maintain_task.done():
            self.maintain_task = asyncio.create_task(
                self._maintain_connection(preferred_address, self.operation_epoch, initial))

    async def _stop_auto_connect(self):
        tasks = (self.maintain_task, self.auto_task)
        for task in tasks:
            if task and not task.done():
                task.cancel()
        for task in tasks:
            if task and not task.done():
                with contextlib.suppress(asyncio.CancelledError):
                    await task

    async def _maintain_connection(self, preferred_address, epoch, initial):
        if initial:
            with contextlib.suppress(asyncio.CancelledError):
                await initial
        delay = RECONNECT_INITIAL_DELAY
        last_address = preferred_address
        pinned_address = bool(preferred_address)
        while epoch == self.operation_epoch:
            if self.client.connected:
                if self.target is not None:
                    last_address = self.target.address
                delay = RECONNECT_INITIAL_DELAY
                await asyncio.sleep(CONNECTION_POLL_SECONDS)
                continue
            await asyncio.sleep(delay)
            if epoch != self.operation_epoch:
                return
            try:
                async with self.lock:
                    if epoch != self.operation_epoch or self.client.connected:
                        continue
                    values = await asyncio.wait_for(
                        scan_targets(timeout=5, scanner=self.scanner), 8)
                    self.targets = {value.address: value for value in values}
                    candidates = [value for value in values
                                  if value.address.casefold() == last_address.casefold()]
                    if not candidates and not pinned_address and len(values) == 1:
                        candidates = values
                    if not candidates and pinned_address:
                        # Windows may keep the bonded Watch physically linked
                        # after the app's old session drops. It then stops
                        # advertising, so scanning alone cannot recover it.
                        candidates = [self.known_target_factory(last_address)]
                    if not candidates:
                        self.ble_error = ("未发现已配置的 StopWatch，等待设备广播后重试"
                                      if last_address else "未发现唯一 StopWatch，等待设备广播后重试")
                        delay = min(delay * 2, RECONNECT_MAX_DELAY)
                        continue
                    last_address = candidates[0].address
                    self.reconnects += 1
                    await asyncio.wait_for(self._connect_locked(candidates[0]), 75)
                    delay = RECONNECT_INITIAL_DELAY
            except asyncio.CancelledError:
                raise
            except (asyncio.TimeoutError, BleConsoleError) as exc:
                self.ble_error = str(exc) if isinstance(exc, BleConsoleError) else "蓝牙重连超时，稍后重试"
                delay = min(delay * 2, RECONNECT_MAX_DELAY)
            except Exception:
                self.ble_error = "蓝牙重连失败，稍后重试"
                delay = min(delay * 2, RECONNECT_MAX_DELAY)

    async def _auto_connect(self, preferred_address, epoch):
        try:
            async with self.lock:
                if epoch != self.operation_epoch:
                    return
                values = await asyncio.wait_for(
                    scan_targets(timeout=5, scanner=self.scanner), 8)
                if epoch != self.operation_epoch:
                    return
                self.targets = {value.address: value for value in values}
                if preferred_address:
                    candidates = [value for value in values
                        if value.address.casefold() == preferred_address.casefold()]
                    if not candidates:
                        candidates = [self.known_target_factory(preferred_address)]
                elif len(values) == 1:
                    candidates = values
                elif not values:
                    self.ble_error = "未发现 StopWatch，请确认设备蓝牙已开启"
                    return
                else:
                    self.ble_error = "发现多台 StopWatch，请手动选择设备"
                    return
                await asyncio.wait_for(self._connect_locked(candidates[0]), 75)
                if epoch != self.operation_epoch:
                    self.enabled = False
                    await self.sound.detach()
                    await self.client.disconnect()
                    self.target = None
        except asyncio.CancelledError:
            raise
        except (asyncio.TimeoutError, BleConsoleError) as exc:
            if epoch == self.operation_epoch:
                self.ble_error = str(exc) if isinstance(exc, BleConsoleError) else "蓝牙扫描或连接超时，请手动重试"
        except Exception:
            if epoch == self.operation_epoch:
                self.ble_error = "蓝牙自动连接失败，请手动扫描连接"

    async def _connect_locked(self, target):
        self.enabled = False
        self.target = None
        try:
            await self.sound.detach()
            await self.client.disconnect()
            self.target = target
            await self.client.connect(target)
            raw_client = getattr(self.client, "client", None)
            if raw_client is not None:
                await self.sound.attach(raw_client)
        except BaseException:
            await self.sound.detach()
            await self.client.disconnect()
            self.enabled = False
            self.target = None
            raise
        self.enabled, self.reconnects = True, 0
        self.flushed_revision = -1
        self.ble_error = ""
        self.text = ""
        self.changed.set()

    def snapshot(self):
        connected = self.device_connected
        return {"connected": connected, "enabled": self.enabled or self.network.wifi.connected,
            "state": self.state, "error": self.error or (self.ble_error if not connected else ""),
            "operation_error": self.error, "ble_error": self.ble_error, "receipt": self.receipt,
            "reconnects": self.reconnects, "audio": self.audio_snapshot(),"network":self.network.snapshot()}

    def audio_snapshot(self):
        return {"job_id": self.audio_job, "mode": self.audio_mode, **self.audio_progress,
            "error": self.audio_error, "gain_db": self.audio_gain_db,
            "result_ready": self.audio_result is not None,
            "running": bool(self.audio_task and not self.audio_task.done())}

    async def scan(self):
        self.operation_epoch += 1
        await self._stop_auto_connect()
        try:
            async with self.lock:
                values = await scan_targets(timeout=5, scanner=self.scanner)
                self.targets = {value.address: value for value in values}
        finally:
            # A manual scan may finish before the Watch starts advertising after
            # power-on. Keep the existing connection policy alive in that case.
            if self.reconnect_enabled:
                address = self.target.address if self.target else self.preferred_address
                self._start_maintain(address)
        return [{"name": x.name, "address": x.address} for x in values]

    async def connect(self, address):
        self.network.router.manual=False
        self.operation_epoch += 1
        await self._stop_auto_connect()
        async with self.lock:
            if address not in self.targets:
                raise BleConsoleError("请先扫描并选择当次发现的设备")
            self.reconnect_enabled = True
            self.preferred_address = address
            try:
                await self._connect_locked(self.targets[address])
            finally:
                self._start_maintain(address)

    async def disconnect(self):
        self.network.router.manual=True
        await self.network.wifi.disconnect()
        self.operation_epoch += 1
        self.reconnect_enabled = False
        self.enabled = False
        await self._stop_auto_connect()
        await self.cancel_audio()
        async with self.lock:
            await self._close_prepared_locked()
            self.enabled = False
            self.target = None
            self.reconnects = 0
            await self.sound.detach()
            await self.client.disconnect()
        self.receipt = ""

    def show(self, state, generation, text="", *, expression=None):
        if generation < self.generation:
            return
        self.generation = generation
        self.state, self.text = state, short_bubble(text)
        self.expression=expression
        self.revision += 1
        self.changed.set()

    async def flush(self):
        async with self.lock:
            if self.network.wifi.connected:
                selected=self.device_client()
                if selected is self.network.wifi:
                    if self.revision<=self.flushed_revision:return
                    revision=self.revision
                    self.receipt=await self.send_expression(self.expression or EXPRESSIONS[self.state])
                    await selected.clear_text()
                    if self.text:await selected.send_text(self.text)
                    if revision==self.revision:self.flushed_revision=revision
                    self.error = ""
                    return
            if not self.enabled or self.target is None:
                return
            if self.client.connected and self.revision <= self.flushed_revision:
                return
            reconnected = False
            if not self.client.connected:
                if self.maintain_task and not self.maintain_task.done():
                    return
                if self.reconnects >= 2:
                    self.error = "设备离线；两次重连已结束，请手动连接"
                    return
                self.reconnects += 1
                await self.client.connect(self.target)
                raw_client = getattr(self.client, "client", None)
                if raw_client is not None:
                    await self.sound.attach(raw_client)
                reconnected = True
            revision = self.revision
            state, text = self.state, "" if reconnected else self.text
            self.receipt = await self.send_expression(self.expression or EXPRESSIONS[state])
            if revision != self.revision:
                return
            await self.device_client().clear_text()
            if text and revision == self.revision:
                self.receipt = await self.device_client().send_text(text)
            if revision == self.revision:
                self.flushed_revision = revision
            self.error = ""

    async def run(self):
        while True:
            try:
                try:
                    await asyncio.wait_for(self.changed.wait(), 1)
                except asyncio.TimeoutError:
                    if (not self.enabled or self.client.connected or self.reconnects >= 2
                            or (self.maintain_task and not self.maintain_task.done())):
                        continue
                self.changed.clear()
                await self.flush()
            except BleConsoleError as exc:
                self.error, self.receipt = str(exc), ""
            except Exception:
                self.error, self.receipt = "设备命令失败，请查看连接状态后重试", ""

    async def close(self):
        await self.cancel_audio()
        await self.close_prepared_audio()
        await self.network.close()
        await self._stop_auto_connect()
        if self.worker:
            self.worker.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.worker
        await self.disconnect()

    def _audio_changed(self, value):
        self.audio_progress = value
        if value.get('stage')=='recording':self.recording_started=time.monotonic()
        if value.get('stage')=='receiving' and value.get('bytes')==0:self.capture_stopped=time.monotonic()

    def _require_audio_idle(self):
        if self.audio_task and not self.audio_task.done():
            raise BleConsoleError("延迟音频任务正在进行，请先取消")
        if not (self.enabled or self.network.wifi.connected) or not self.device_connected:
            raise BleConsoleError("StopWatch 未连接")

    @staticmethod
    def _audio_identity(raw):
        wifi=getattr(raw,'wifi',None)
        return ('wifi',id(wifi),wifi.boot,wifi.session) if wifi is not None else ('ble',id(raw))

    async def _close_prepared_locked(self):
        audio,self.prepared_audio=self.prepared_audio,None
        self.prepared_identity=None
        if audio is not None:await audio.close()

    async def close_prepared_audio(self):
        async with self.lock:await self._close_prepared_locked()

    async def prepare_audio(self):
        """Negotiate with mic OFF; PRODUCT_ARM still requires a fresh device click."""
        async with self.lock:
            self._require_audio_idle()
            if self.dialogue_pinned:return False
            raw=self.network.audio()
            try:
                if raw is None or not raw.is_connected:raise BleConsoleError('StopWatch 未连接')
                identity=self._audio_identity(raw)
                audio=self.prepared_audio
                if audio and self.prepared_identity==identity and not audio.closed and audio.failure is None:return True
                await self._close_prepared_locked()
                audio=AudioClient(raw,packet_bytes=4096) if self.network.router.active=='wifi' else AudioClient(raw)
                try:await audio.open()
                except BaseException:
                    await audio.close();raise
                self.prepared_audio,self.prepared_identity=audio,identity
                return True
            finally:
                # A physical click may pin its route while HELLO is in flight.
                # Preparation must not release that new conversation's route.
                if not self.dialogue_pinned:self.network.router.end()

    async def _run_audio(self, mode, pcm=None, rate=None, speech_text=None, speech_expression=None):
        async with self.lock:
            raw = self.network.audio()
            if raw is None or not getattr(raw, "is_connected", False):
                if not self.dialogue_pinned:self.network.router.end()
                raise BleConsoleError("StopWatch 未连接")
            prepared=self.prepared_audio
            reuse=(mode=='productrecord' and self.dialogue_pinned and prepared is not None and
                   self.prepared_identity==self._audio_identity(raw) and not prepared.closed and prepared.failure is None)
            if reuse:
                self.audio,self.prepared_audio=prepared,None;self.prepared_identity=None
            else:
                await self._close_prepared_locked()
                self.audio = AudioClient(raw,packet_bytes=4096) if self.network.router.active=='wifi' else AudioClient(raw)
            bubble = short_bubble(speech_text) if speech_text else ""
            bubble_started = False
            async def reveal_after_transfer():
                nonlocal bubble_started
                self.receipt = await self.send_expression(speech_expression or EXPRESSIONS["idle"])
                bubble_started = True
                self.receipt = await self.device_client().send_text(bubble)
                self.state, self.text, self.expression = "idle", bubble, speech_expression
                self.revision += 1
                self.flushed_revision = self.revision
            try:
                if not reuse:await self.audio.open()
                if bubble:
                    # A queued idle/processing flush must not show an older
                    # bubble after the audio task releases the BLE writer.
                    self.receipt = await self.device_client().clear_text()
                    self.text = ""
                    self.revision += 1
                    self.flushed_revision = self.revision
                if mode in ("record", "echo", "productrecord"):
                    record_face_sent=False
                    async def record_progress(value):
                        nonlocal record_face_sent
                        self._audio_changed(value)
                        if value.get('stage')=='recording' and speech_expression and not record_face_sent:
                            record_face_sent=True
                            self.receipt=await self.send_expression(speech_expression)
                    captured, captured_rate = await self.audio.record(record_progress,product=True) if mode=='productrecord' else await self.audio.record(self._audio_changed)
                    if mode in ("record","productrecord"):
                        self.audio_result = make_wav(captured, captured_rate)
                    else:
                        await self.audio.play(captured, captured_rate, self._audio_changed)
                else:
                    await self.audio.play(pcm, rate, self._audio_changed,
                                          before_play=reveal_after_transfer if bubble else None)
            except BaseException:
                if bubble_started:
                    cleared = False
                    try:
                        self.receipt = await self.device_client().clear_text()
                        cleared = True
                    except Exception:
                        pass
                    self.text = ""
                    self.revision += 1
                    if cleared:
                        self.flushed_revision = self.revision
                    else:
                        self.changed.set()
                raise
            finally:
                await self.audio.close()
                self.audio = None
                if not self.dialogue_pinned:self.network.router.end()

    def _start_audio(self, mode, pcm=None, rate=None, gain_db=0.0, speech_text=None, speech_expression=None):
        if mode in ('record','echo','productrecord'):self.capture_stopped=None
        self._require_audio_idle()
        self.audio_job, self.audio_mode = str(uuid.uuid4()), mode
        self.recording_started=None
        self.audio_result, self.audio_error = None, ""
        self.audio_gain_db = gain_db
        self.audio_progress = {"stage": "starting", "bytes": 0, "total": len(pcm or b""), "elapsed": 0, "rate": 0}
        async def runner():
            try:
                await self._run_audio(mode, pcm, rate, speech_text, speech_expression)
            except asyncio.CancelledError:
                self.audio_progress = {**self.audio_progress, "stage": "cancelled"}
                raise
            except Exception as exc:
                self.audio_error = str(exc).strip() or (
                    "Watch 音频通信超时；请检查蓝牙连接，旧版固件还需打开 Audio test"
                    if isinstance(exc, TimeoutError) else "Watch 音频任务意外失败")
                self.audio_progress = {**self.audio_progress, "stage": "error"}
        self.audio_task = asyncio.create_task(runner())
        return self.audio_snapshot()

    def start_audio_record(self, echo=False):
        return self._start_audio("echo" if echo else "record")

    def start_audio_play(self, wav, *, speech=False, speech_text=None, speech_expression=None):
        try:
            pcm, rate = read_wav(wav)
        except ValueError as exc:
            raise BleConsoleError(str(exc)) from exc
        pcm, gain_db = boost_watch_speech(pcm) if speech else (pcm, 0.0)
        return self._start_audio("play", pcm, rate, gain_db, speech_text if speech else None,
                                 speech_expression if speech else None)

    async def cancel_audio(self):
        task = self.audio_task
        if task and not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
        return self.audio_snapshot()

    def take_audio_result(self, job_id):
        if job_id != self.audio_job or self.audio_result is None:
            raise BleConsoleError("录音结果不存在、尚未完成或已释放")
        result, self.audio_result = self.audio_result, None
        return result

    async def play_sound(self, sound_id):
        self._require_audio_idle()
        async with self.lock:
            if self.device_client() is self.network.wifi:return (await self.network.wifi.request(4,bytes([1,sound_id]))).decode()
            return await self.sound.play(sound_id)

    async def stop_sound(self):
        if self.network.wifi.connected:
            return (await self.network.wifi.request(4,b'\0\0')).decode()
        async with self.lock:
            return await self.sound.stop()

    async def set_sound_volume(self, volume):
        self._require_audio_idle()
        async with self.lock:
            if self.device_client() is self.network.wifi:return (await self.network.wifi.request(4,bytes([2,volume]))).decode()
            return await self.sound.set_volume(volume)

    async def play_expression(self, expression, mode="once"):
        """Send one validated manual expression over the existing BLE writer."""
        if expression not in BLE_EXPRESSIONS and not is_custom_command(expression):
            raise BleConsoleError("未知 StopWatch 表情")
        if mode not in ("once", "loop"):
            raise BleConsoleError("播放方式只能是 once 或 loop")
        self._require_audio_idle()
        async with self.lock:
            command = expression if mode == "once" else f"loop {expression}"
            self.receipt = await self.send_expression(command,restart=True)
            self.state, self.text, self.error = expression, "", ""
            return {"receipt": self.receipt, "expression": expression, "mode": mode}

    async def auto_expression(self, expression, guard):
        """Use the existing BLE writer; recheck cancellation after waiting for it."""
        if not self.device_connected or not (self.enabled or self.network.wifi.connected):
            return "offline"
        async with self.lock:
            if not guard():
                return "suppressed"
            self._require_audio_idle()
            self.receipt = await self.send_expression(f"loop {expression}")
            return "accepted"

    async def auto_notify(self, expression, text, guard):
        if not self.device_connected or not (self.enabled or self.network.wifi.connected):
            return "offline"
        async with self.lock:
            if not guard():
                return "suppressed"
            self._require_audio_idle()
            self.receipt = await self.send_expression(expression)
            if not guard():
                return "suppressed"
            self.receipt = await self.device_client().send_text(text)
            return "accepted"

    async def auto_sound(self, sound_id, guard):
        if not self.device_connected or not (self.enabled or self.network.wifi.connected):
            return "offline"
        async with self.lock:
            if not guard():
                return "suppressed"
            self._require_audio_idle()
            if self.device_client() is self.network.wifi:
                await self.network.wifi.request(4,bytes([1,sound_id]))
            else:
                await self.sound.play(sound_id)
            return "device_acknowledged"

    async def auto_speech(self, wav, phrase, guard, expression=None):
        if not self.device_connected or not (self.enabled or self.network.wifi.connected):
            return "offline"
        if not guard():
            return "suppressed"
        self.start_audio_play(wav, speech=True, speech_text=phrase, speech_expression=expression)
        await self.audio_task
        return "device_playback_completed" if not self.audio_error else "failed"

    async def set_bubble(self, text):
        self._require_audio_idle()
        async with self.lock:
            self.receipt = await self.device_client().send_text(text)
            self.text, self.error = text, ""
            return {"receipt": self.receipt, "text": text}

    async def clear_bubble(self):
        self._require_audio_idle()
        async with self.lock:
            self.receipt = await self.device_client().clear_text()
            self.text, self.error = "", ""
            return {"receipt": self.receipt}
